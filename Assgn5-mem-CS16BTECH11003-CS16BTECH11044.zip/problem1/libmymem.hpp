void* mymalloc(int size);
void myfree(void *ptr);