#ifndef H_Process
#define H_Process

#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <sstream>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <stdio.h>
#include <semaphore.h>

using namespace std;

class Process
{
public:
  int deadline, comp_time, relative_dl,
  rem_comp_time, pid;
  string tp_sem_name, fp_sem_name;
  vector<string> instructions;


  int parse_instr(string instruction_to_parse);
  /*
  Parses the raw string for the instruction.
  INPUT: Raw string for the instructions.
  OUTPUT: Integer representing what the instruction is
  (0: calc, 1: use resources, 2: release, 3: request)
  */
  string extract_ints(string instruction);
  /*
  Helper function to extract the integer or the vector
  from the instructions list for each process.
  INPUT: the string representing the instruction.
  OUTPUT: the integer representing the computation time
  for useresources or calculate. Or a vector for the request
  and release instructions.
  */
  void calculate(string instr_str, int* timer, sem_t* timer_mutex);
  /*
  Takes the calc instruction from a process
  and extracts the computation time in the parentheses
  and adds the time to the global timer.
  */
  void use_resources(string instr_str, int* timer, sem_t* timer_mutex);
  /*
  Takes the use resource instruction from a process
  and extracts the computation time in the parentheses
  and adds the time to the global timer.
  */
  void release(string rel_instr, int R, int* timer, int* req_array, sem_t* timer_mutex);
  /*
  Extracts the resource vector from a release resources instruction
  and updates the request array in shared memory with the vector
  so the parent process can process it.
  */
  void request(string req_instr, int R, int* timer, int* req_array, sem_t* timer_mutex);
  /*
  Extracts the resource vector from a request resources instruction
  and updates the request array in shared memory with the vector
  so the parent process can process it.
  */


};

int Process::parse_instr(string instruction_to_parse)
{
  string substring;
  substring = instruction_to_parse.substr(0, 3);
  if (substring == "cal")
  {
    return 0;
  }
  else if (substring == "use")
  {
    return 1;
  }
  else if (substring == "rel")
  {
    return 2;
  }
  else
  {
    return 3;
  }
}

void Process::calculate(string calc_instr, int* timer, sem_t* timer_mutex)
{
  cout << "Process " << pid + 1 << " is calculating." << endl;
  int calc_time, beg_pos, end_pos, len;
  stringstream css;
  string calc_substring;
  calc_substring = extract_ints(calc_instr);
  css << calc_substring;
  css >> calc_time;

  sem_wait(timer_mutex);
  *timer += calc_time;
  sem_wait(timer_mutex);

  rem_comp_time -= calc_time;

  cout << "Process " << pid + 1 << " is finished calculating." << endl;
  cout << "Global timer is now: " << *timer << endl;

}

void Process::use_resources(string ur_instr, int* timer, sem_t* timer_mutex)
{
  cout << "Process " << pid +1  << " is using resources." << endl;

  int UR_time;
  stringstream ur_ss;
  string ur_substring;
  ur_substring = extract_ints(ur_instr);
  cout << ur_substring << endl;
  ur_ss << ur_substring;
  ur_ss >> UR_time;

  sem_wait(timer_mutex);
  *timer += UR_time;
  sem_post(timer_mutex);

  rem_comp_time -= UR_time;
  cout << "Global timer is now: " << *timer << endl;

}

void Process::release(string rel_instr, int R,
  int* timer, int* req_array, sem_t* timer_mutex)
{
  cout << "Process" << pid + 1<< " hit release instruction" << endl;
  string rel_substr, token;
  int resource, i = 1;
  stringstream rel_ss;
  rel_substr = extract_ints(rel_instr);
  //cout << rel_substr << endl;
  req_array[0] = 1;
  //cout << rel_substr << endl;
  rel_ss.str(rel_substr);
  while(getline(rel_ss, token, ',') && i < R + 1)
  {
    resource = stoi(token);
    req_array[i] = resource;
    i++;
  }
  cout << "Process" << pid + 1 << " updated RELEASE vector." << endl;
  cout << "RELEASE vector is: ";
  for (int i = 0; i < R + 1; i++)
  {
    cout << req_array[i] << " ";
  }
  cout << endl;

  sem_wait(timer_mutex);
  *timer += 1;
  sem_post(timer_mutex);

  cout << "Global timer is now: " << *timer << endl;
}
void Process::request(string req_instr, int R,
  int* timer, int* req_array, sem_t* timer_mutex)
{
  cout << "Process " << pid + 1 << " hit request instruction." << endl;
  string req_substr, token;
  int resource, i =1;
  stringstream req_ss;
  req_substr = extract_ints(req_instr);
  req_array[0] = 0;
  req_ss.str(req_substr);
  while(getline(req_ss, token, ',') && i < R + 1)
  {
    resource = stoi(token);
    req_array[i] = resource;
    i++;
  }
  cout << "Process " << pid + 1<< " updated REQUEST vector." << endl;
  cout << "REQUEST vector is: ";
  for (int i = 0; i < R + 1; i++)
  {
    cout << req_array[i] << " ";
  }
  cout << endl;

  sem_wait(timer_mutex);
  *timer += 1;
  sem_post(timer_mutex);

  cout << "Global timer is now: " << *timer << endl;

}

string Process::extract_ints(string instruction)
{
  string substring, delimiter = "(";
  int beg_pos, end_pos, len;
  beg_pos = instruction.find(delimiter) + 1;
  end_pos = instruction.find(")");
  len = end_pos - beg_pos;
  substring = instruction.substr(beg_pos, len);

  return substring;

}

#endif
