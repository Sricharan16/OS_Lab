#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <sstream>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <stdio.h>
#include <semaphore.h>

#include "process.h"

using namespace std;

void debug_print(vector<int> matrix, int R);
void get_proc_info(ifstream& fin, int& R,
  int& P, int& total_res, vector<int>& available);
/*
Retrieves the relevant info for the num of resources and processes
from the text file. Also calculates the total number of elements
for the resource matrix.
*/
void get_max(ifstream& fin, int P, int R,
  vector<vector<int> >& max_matrix);
/*
Fills the max resource matrix using the info from the .txt file.
*/
void get_proc_instr(ifstream& fin, vector<Process>& process, int P);
/*
Reads the deadlines, comp time, and instruction block for each
process and inputs into their respective process objects.
*/
vector<vector<int> > calc_need(vector<vector<int> > alloc_matrix,
  vector<vector<int> > max_matrix, int P, int R);
/*
Caclulate the need matrix using the formula need = max - alloc
*/
int find_shortest_proc(int P, int last_run_pid, vector<Process> process);
/*
Finds the process with the shortest execution/computation time.
Returns an int representing the id of the process.
*/
bool bankers_algo(int* req, vector<int> avail, vector<vector<int> > need,
  vector<vector<int> > alloc, vector<vector<int> > maxm, int R, int P, int pid);
/*
Checks to see if the request will cause a deadlock.
Input: the alloc and max matrices, the request array, num of processes and
resources, and the id of the process to check for.
Output: a boolean specifying if its safe to grant the request. True if safe,
false if unsafe.
*/
bool isSafe(vector<int> available, vector<vector<int> > maxm,
  vector<vector<int> > alloc, int P, int R);
/*
The safety check algorithm from the Banker's algorithm
*/
void grant_resources(int* req, vector<int>& available,
  vector<vector<int> >& need, vector<vector<int> >& alloc,int R, int pid);
/*
Updates the available, alloc, and need matrices to reflect resources being
granted to a process.
*/
void release_res(int* req, vector<int>& available,
  vector<vector<int> >& need, vector<vector<int> >& alloc,int R, int pid);
/*
Subtracts the resources released by the process' release instruction
from the alloc matrix and adds them to the need and available matrix.
*/
void run_process(Process process, vector<sem_t*> to_process_sem, vector<sem_t*> from_process_sem,
  int* timer, int* req_array, int R, int pid, sem_t* timer_mutex);
/*
Function to run through each process' instructions. Waits and signals to
the parent process to signal that the request vector has been updated
so the parent can do Banker's algorithm on the request or release resources.
*/


int main(int argc, char* argv[])
{
  int R, P, total_res, shortest_pid = -1;
  int last_run_pid = -1, n_proc_finish = 0, fpid;
  string file_name, instr_str, tp_str_name, fp_str_name;
  ifstream fin;
  vector<int> available, request;
  file_name = argv[1];
  fin.open(file_name);
  pid_t pid;
  bool bankers = false;

  get_proc_info(fin, R, P, total_res, available);

  sem_t* timer_mutex;
  vector<sem_t*> to_process_sem(P), from_process_sem(P);

  sem_unlink("timer_mutex");
  //create mutex semaphore to protect the timer. Initialize to 1
  //since its a mutex lock.
  timer_mutex = sem_open("timer_mutex", O_CREAT | O_EXCL, 0777, 1);

  //Mac OS X does not support unnamed semaphores so I had to
  //write this loop to create the vectors of named semaphores
  //using sem_open()
  for (int i = 0; i < P; i++)
  {
    tp_str_name = "to_process" + to_string(i);
    fp_str_name = "from_process" + to_string(i);

    sem_unlink(tp_str_name.c_str());
    sem_unlink(fp_str_name.c_str());
    to_process_sem[i] = sem_open(tp_str_name.c_str(), O_CREAT | O_EXCL, 0777, 0);
    from_process_sem[i] = sem_open(fp_str_name.c_str(), O_CREAT | O_EXCL, 0777, 1);
  }


  cout << "# Resources: " << R << endl;
  cout << "# Processes: " << P << endl;
  cout << "# Total Resources: " << total_res << endl;

  //create the vector of process objects
  vector<Process> process(P);

  //Create the matrices needed for Banker's Algorithm
  vector< vector<int> > need_matrix(P, vector<int>(R));
  vector< vector<int> > alloc_matrix(P, vector<int>(R));
  vector< vector<int> > max_matrix(P, vector<int>(R));

  //Get the maximum resources for the max matrix.
  get_max(fin, P, R, max_matrix);
  //Read the instructions for each process into the process objects.
  get_proc_instr(fin, process, P);
  //Calc the need matrix.
  need_matrix = calc_need(alloc_matrix, max_matrix, P, R);


  //Create the shared memory variable for the timer
  int timer_shmid;
	key_t timer_key = 1111;
	size_t timer_size = sizeof(int);
	timer_shmid = shmget(timer_key, timer_size, 0600 | IPC_CREAT);
  //err checking for shmget()
  if (timer_shmid == -1)
  {
    perror("shmget(timer) failed");
    exit(0);
  }
	int* timer_shm = (int*) shmat(timer_shmid, NULL, 0);

  //create the shared memory for the request array that
  //the processes will update
  int req_shmid;
  key_t req_key = 4444;
  size_t req_key_size = (R + 1) *sizeof(int);
  req_shmid = shmget(req_key, req_key_size, 0600 | IPC_CREAT);
  if (req_shmid == -1)
  {
    perror("shmget(req_key) failed");
    exit(0);
  }
  int* req_array = (int*)shmat(req_shmid, NULL, 0);

  //Spawn the processes. If process is a child, break it
  //out of the loop so it doesn't keep forking extra processes
  for (int i = 0; i < P; i++)
  {
    pid = fork();
    if (pid == 0) break;
    else fpid = i;
  }


  if (pid == 0)
  {
    //Child gets here
    //cout << "starting child process" << endl;
    run_process(process[fpid], to_process_sem, from_process_sem,
      timer_shm, req_array, R, fpid, timer_mutex);

    }
  else
    {

        // parent process
        while (n_proc_finish < P)
        {
          cout << "starting parent process" << endl;
          shortest_pid = find_shortest_proc(P, last_run_pid, process);
          cout << "Shortest process is: " << shortest_pid + 1<< endl;
          sem_wait(from_process_sem[shortest_pid]);
          cout << "parent passed wait sem" << endl;
          sem_post(to_process_sem[shortest_pid]);
          sem_wait(from_process_sem[shortest_pid]);
          if (req_array[0] == 0)
          {
              cout << "Begin Banker's Algorithm:" << endl;
              if ((bankers = bankers_algo(req_array, available, need_matrix, alloc_matrix,
                max_matrix, R, P, shortest_pid)))
              {
                for (int i = 0; i < R; i++)
                {
                  grant_resources(req_array, available, need_matrix, alloc_matrix, R, shortest_pid);

                  //Have to decrement remaining comp time by 1
                  //since request was granted.
                  process[shortest_pid].rem_comp_time -= 1;
                }
              }
              else
              {
                cout << "Could not find safe state" << endl;
              }
              last_run_pid = shortest_pid;
              sem_post(to_process_sem[shortest_pid]);
              continue;
          }
          else if (req_array[0] == 1)
          {
            release_res(req_array, available,
              need_matrix,  alloc_matrix, R, shortest_pid);
            sem_post(to_process_sem[shortest_pid]);
            continue;
          }
          else
          {
            //if req array[0] has value of 2. That means the process finished.
            n_proc_finish++;
          }

        }
    }

  shmdt(timer_shm);
  shmdt(req_array);

  shmctl(req_shmid, IPC_RMID, NULL);
  shmctl(timer_shmid, IPC_RMID, NULL);


  for (int i = 0; i < P; i++)
  {
    tp_str_name = "to_process" + to_string(i);
    fp_str_name = "from_process" + to_string(i);

    sem_unlink(tp_str_name.c_str());
    sem_unlink(fp_str_name.c_str());
  }


  return 0;

}

void run_process(Process process, vector<sem_t*> to_process_sem, vector<sem_t*> from_process_sem,
  int* timer_shm, int* req_array, int R, int pid, sem_t* timer_mutex)
{
  sem_wait(to_process_sem[pid]);
  int instr = -1;
  for (int i = 0; i < process.instructions.size(); i++)
  {
    int instr = process.parse_instr(process.instructions[i]);
    switch (instr)
    {
      case 0:
        process.calculate(process.instructions[i], timer_shm, timer_mutex);
        break;
      case 1:
        process.use_resources(process.instructions[i], timer_shm, timer_mutex);
        break;
      case 2:
        process.release(process.instructions[i], R, timer_shm, req_array, timer_mutex);
        sem_post(from_process_sem[pid]);
        sem_wait(to_process_sem[pid]);
        break;
      case 3:
        process.request(process.instructions[i], R, timer_shm, req_array, timer_mutex);
        sem_post(from_process_sem[pid]);
        sem_wait(to_process_sem[pid]);
        break;
    }
  }
  req_array[0] = 2;
  cout << "Process " << pid << " finish. Exiting." << endl;;
  sem_post(from_process_sem[pid]);
  exit(0);
}

void get_proc_info(ifstream& fin, int& R,
  int& P, int& total_res, vector<int>& available)
{
  int x;
  fin >> R;
  fin >> P;
  total_res = R * P;

  for (int i = 0; i < R; i++)
  {
    fin >> x;
    available.push_back(x);
    cout << "# instances for Resource " << i+1 << ": " << available[i] << endl;;
  }
}

void get_max(ifstream& fin, int P, int R,
  vector<vector<int> >& max_matrix)
{
  int res_max;
  string max_str, temp, delimiter = "=";
  stringstream ss;
  cout << "Max Matrix:" << endl;
  for (int i = 0; i < P; i++)
  {
    for (int j = 0; j < R; j++)
    {
      fin >> max_str;
      //cout << max_str << endl;
      temp = max_str.substr(max_str.find(delimiter)+1, max_str.length());
      //cout << temp << " ";
      ss << temp;
      ss >> res_max;

      max_matrix[i][j] = res_max;

      cout << max_matrix[i][j] << " ";

      ss.clear();
      max_str = "";

    }
    cout << endl;
  }

}

void get_proc_instr(ifstream& fin, vector<Process>& process,int P)
{
  string instr_str;
  int instr_code;
  for (int i = 0; i < P; i++)
  {
    fin >> instr_str;
    if (instr_str[0] == 'p')
    {
      process[i].tp_sem_name = to_string(i);
      process[i].pid = i;
      fin >> process[i].deadline;
      fin >> process[i].comp_time;

      process[i].rem_comp_time = process[i].comp_time;
      process[i].relative_dl = process[i].deadline;

      cout << "Process " << i << " deadline: " <<process[i].deadline << " ";
      cout << "exec time: " << process[i].comp_time << endl;

      fin >> instr_str;
      int k = 0;
      while (instr_str != "end")
      {
        process[i].instructions.push_back(instr_str);
        cout << process[i].instructions[k] << endl;
        fin >> instr_str;
        k++;
      }
    }
    else
    {
      cout << "Warning: could not find beginning of instr block!" << endl;
      exit(0);
    }
  }
}


vector<vector<int> > calc_need(vector<vector<int> > alloc_matrix,
  vector<vector<int> > max_matrix, int P, int R)
{
  vector<vector<int> > need_matrix(P, vector<int>(R));
  for (int i = 0; i < P; i++)
  {
    for (int j = 0; j < R; j++)
    {
      need_matrix[i][j] = max_matrix[i][j] - alloc_matrix[i][j];
    }
  }
  return need_matrix;
}

int find_shortest_proc(int P, int last_run_pid, vector<Process> process)
{
  int minimum = 1000, shortest_proc_id;
  for (int i = 0; i < P; i++)
  {
    if (process[i].pid == last_run_pid)
    {
      continue;
    }
    if (process[i].comp_time < minimum)
    {
      minimum = process[i].comp_time;
      shortest_proc_id = process[i].pid;
    }
  }

  return shortest_proc_id;
}

bool bankers_algo(int* req, vector<int> avail, vector<vector<int> > need,
  vector<vector<int> > alloc, vector<vector<int> > maxm, int R, int P, int pid)
{
  bool aBool = true, isItSafe = false;
  for (int i = 0; i < R; i++)
  {
    if (req[i+1] > need[pid][i])
    {
      cout << "Error: Request > Need" << endl;
      aBool = false;
      break;
    }
    if (req[i+1] > avail[i])
    {
      cout << "Warning: Request > Available" << endl;
      aBool = false;
      break;
    }
  }
  if (aBool)
  {

    grant_resources(req, avail, need, alloc, R, pid);

    isItSafe = isSafe(avail, maxm, alloc, P, R);
    return isItSafe;
  }
  else
  {
    return isItSafe;
  }


}

bool isSafe(vector<int> available, vector<vector<int> > maxm,
  vector<vector<int> > alloc, int P, int R)
{
    vector<vector<int> > need(P, vector<int>(R));

    // Function to calculate need matrix
    need = calc_need(alloc, maxm, P, R);

    // Mark all processes as unfinished
    bool finish[P];

    // To store safe sequence
    int safeSeq[P];

    // Make a copy of available resources
    int work[R];
    for (int i = 0; i < R ; i++)
        work[i] = available[i];

    // While all processes are not finished
    // or system is not in safe state.
    int count = 0;
    while (count < P)
    {
        // Find a process which is not finish and
        // whose needs can be satisfied with current
        // work[] resources.
        bool found = false;
        for (int pp = 0; pp < P; pp++)
        {
            // First check if a process is finished,
            // if no, go for next condition
            if (finish[pp] == 0)
            {
                // Check if for all resources of
                // current P need is less
                // than work
                int j;
                for (j = 0; j < R; j++)
                    if (need[pp][j] > work[j])
                    {
                      cout << "P" << pp << " need > work." << endl;
                        break;
                    }


                // If all needs of p were satisfied.
                if (j == R)
                {
                    // Add the allocated resources of
                    // current P to the available/work
                    // resources i.e.free the resources
                    for (int k = 0 ; k < R ; k++)
                        work[k] += alloc[pp][k];

                    // Add this process to safe sequence.
                    safeSeq[count++] = pp;

                    // Mark this p as finished
                    finish[pp] = 1;

                    found = true;
                }
            }
        }

        // If we could not find a next process in safe
        // sequence.
        if (found == false)
        {
            cout << "System is not in safe state" << endl;
            return false;
        }
    }

    // If system is in safe state then
    // safe sequence will be as below
    cout << "System is in safe state.\nSafe"
         " sequence is: ";
    for (int i = 0; i < P ; i++)
        cout << safeSeq[i] << " ";

    return true;
}

void release_res(int* req, vector<int>& available,
  vector<vector<int> >& need, vector<vector<int> >& alloc,int R, int pid)
{
  for (int i = 0; i < R; i++)
  {
    available[i] += req[i+1];
    alloc[pid][i] -= req[i+1];
    need[pid][i] += req[i+1];
  }
}

void grant_resources(int* req, vector<int>& available,
  vector<vector<int> >& need, vector<vector<int> >& alloc, int R, int pid)
{
  for(int i =0; i< R; i++)
  {
    available[i] -= req[i+1];
    alloc[pid][i] += req[i+1];
    need[pid][i] -= req[i+1];
  }
}

void debug_print(vector<int> matrix, int R)
{
  for (int i = 0; i < R; i++)
  {
    cout << matrix[i] << " ";
  }
  cout << endl;
}
