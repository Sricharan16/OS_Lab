#include <thread>
#include <iostream>
#include <string>
#include <random>
#include "CircleBuffer.h"
#include "ThreadSafeCircleBuffer.h"
#include "Semaphore.h"


void testCircleBuffer();
void testSemaphore();
void testThreadSafeCircleBuffer();

void main() {
	//testCircleBuffer();
	//testSemaphore();
	testThreadSafeCircleBuffer();
}

void testThreadSafeCircleBuffer() {
	// Test setup
	const int MAX_WRITER_COUNT = 100;
	const unsigned int BUFFER_SIZE = 40;
	const int MIN_BUFFER_DELAY = 200;
	const int MAX_BUFFER_DELAY = 500;

	// Create thread-safe circle buffer
	ThreadSafeCircleBuffer<std::string, BUFFER_SIZE> cb;

	// Variable to decide when to kill writeres
	int aborted = false;

	// Create random number generator for writer delay
	std::default_random_engine eng;
	std::uniform_int_distribution<int> rand(MIN_BUFFER_DELAY, MAX_BUFFER_DELAY);

	// Create reader thread
	std::thread reader([&] {
		int selfBalancingDelay = 1;
		while (!aborted || cb.count() > 0) {
			std::string str;
			if (cb.pull(str)) {
				for (unsigned int i = 0; i < BUFFER_SIZE; ++i) {
					if (i < cb.count())
						std::cout << '#';
					else
						std::cout << ' ';
				}
				std::cout << ' ' << str << std::endl;
			}
			if (cb.count() < (BUFFER_SIZE / 2))
				selfBalancingDelay++;
			else
				selfBalancingDelay--;
			std::this_thread::sleep_for(std::chrono::milliseconds(selfBalancingDelay));
		}
#ifdef VERBOSE_DEBUG
		std::cout << "Reading thread ended." << std::endl;
#endif
	});

	// Create write threads
	std::thread writers[MAX_WRITER_COUNT];
	for (int i = 0; i < MAX_WRITER_COUNT; i++)
		writers[i] = std::thread([&](int t_id) {
		int id = t_id;
		unsigned long counter = 0;
		while (!aborted) {
			char buffer[32];
			snprintf(buffer, 32, "Thread %d: %d", id, counter++);
			cb.push(buffer);
			std::this_thread::sleep_for(std::chrono::milliseconds(rand(eng)));
		}
#ifdef VERBOSE_DEBUG
		std::cout << "Writing thread " << id << " ended." << std::endl;
#endif
	}, i);

	// Wait for enter
	getchar();
	aborted = true;

	for (auto& t : writers)
		t.join();

	cb.cancelPull();
	reader.join();
}


void testSemaphore() {
	const int MAX_THREAD_COUNT = 1000;
	std::thread threads[MAX_THREAD_COUNT];
	Semaphore s(1);
	int someInt = 0;
	auto threadCollision = [&]() {
		std::cout << someInt++ << " ";
	};
	for (auto& t : threads)
		t = std::thread(threadCollision);
	for (auto& t : threads)
		t.join();
	std::cout << std::endl;
	someInt = 0;
	auto singleThreadOnly = [&]() {
		s.wait();
		std::cout << someInt++ << " ";
		s.signal();
	};
	for (auto& t : threads)
		t = std::thread(singleThreadOnly);
	for (auto& t : threads)
		t.join();
	std::cout << std::endl;
}

void testCircleBuffer() {
	CircleBuffer<int, 10> cb;
	for (int i = 0; i < 30; ++i) {
		try {
			cb.push((i * 2) % 255);
			cb.push((i * 2 + 1) % 255);
		}
		catch (std::exception ex) {
			std::cout << ex.what() << std::endl;
		}
		try {
			std::cout << cb.pull() << std::endl;
		}
		catch (std::exception ex) {
			std::cout << ex.what() << std::endl;
		}
	}
}