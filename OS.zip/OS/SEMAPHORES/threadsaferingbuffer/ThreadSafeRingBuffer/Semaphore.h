#pragma once

#include <mutex>
#include <condition_variable>

class Semaphore
{
	int m_value;
	int wakeups;
	std::mutex m_lock;
	std::condition_variable cv;
public:
	Semaphore(int initialValue) : m_value(initialValue), wakeups(0) {};
	void signal();
	void wait();
	void cancelWait();
	~Semaphore() {};
};