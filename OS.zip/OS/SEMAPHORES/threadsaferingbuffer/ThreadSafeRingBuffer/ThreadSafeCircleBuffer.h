#pragma once

#include "Semaphore.h"

template <typename T, size_t t_bufferSize>
class ThreadSafeCircleBuffer
{
	T m_buffer[t_bufferSize ? t_bufferSize : 1];
	int m_readIndex;
	int m_writeIndex;
	size_t m_count;
	const T* m_endPtr;
	Semaphore avoidEmptyRead;
	Semaphore avoidFullWrite;
	Semaphore mutex;
public:
	ThreadSafeCircleBuffer() : m_readIndex(0), m_writeIndex(0),
		avoidEmptyRead(0), avoidFullWrite(t_bufferSize), mutex(1),
		m_count(0) {}
	void push(const T& val);
	bool pull(T& val);
	void cancelPull();
	size_t count() const { return m_count; }
	~ThreadSafeCircleBuffer() {}
};

template <typename T, size_t t_bufferSize>
void ThreadSafeCircleBuffer<T, t_bufferSize>::push(const T& val) {
	avoidFullWrite.wait();
	mutex.wait();
	m_buffer[m_writeIndex] = val;
	m_writeIndex = (m_writeIndex + 1) % t_bufferSize;
	m_count++;
	mutex.signal();
	avoidEmptyRead.signal();
}

// Returning true indicates a valid value
template <typename T, size_t t_bufferSize>
bool ThreadSafeCircleBuffer<T, t_bufferSize>::pull(T& val) {
	avoidEmptyRead.wait();
	mutex.wait();
	if (m_count == 0) {
		mutex.signal();
		return false;
	}
	val = m_buffer[m_readIndex];
	m_readIndex = (m_readIndex + 1) % t_bufferSize;
	m_count--;
	mutex.signal();
	avoidFullWrite.signal();
	return true;
}

template <typename T, size_t t_bufferSize>
void ThreadSafeCircleBuffer<T, t_bufferSize>::cancelPull() {
	avoidEmptyRead.signal();
}