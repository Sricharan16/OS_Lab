#include "Semaphore.h"


void Semaphore::wait() {
	std::unique_lock<std::mutex> lck(m_lock);
	m_value--;
	if (m_value < 0) {
		do {
			cv.wait(lck);
		} while (wakeups < 1);
		wakeups--;
	}
}

void Semaphore::signal() {
	std::unique_lock<std::mutex> lck(m_lock);
	m_value++;
	if (m_value <= 0) {
		wakeups++;
		cv.notify_one();
	}
}

void Semaphore::cancelWait() {
	wakeups = 1;
	cv.notify_all();
}