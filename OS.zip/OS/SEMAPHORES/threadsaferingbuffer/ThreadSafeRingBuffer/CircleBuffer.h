#pragma once

template <typename T, size_t t_bufferSize>
class CircleBuffer {
	T m_buffer[t_bufferSize ? t_bufferSize : 1];
	int m_readIndex;
	int m_writeIndex;
	size_t m_count;
public:
	using value_type = T;
	const int bufferSize = t_bufferSize;
	//using bufferSize = t_bufferSize;
	CircleBuffer() : m_readIndex(0), m_writeIndex(0), m_count(0) {}
	void push(T val);
	T pull();
	size_t count() { return m_count; }
};

template <typename T, size_t t_bufferSize>
void CircleBuffer<T, t_bufferSize>::push(T val) {
	if (m_count == t_bufferSize)
		throw std::exception("buffer full");
	m_buffer[m_writeIndex] = val;
	m_writeIndex++;
	if (m_writeIndex == t_bufferSize)
		m_writeIndex = 0;
	m_count++;
}

template <typename T, size_t t_bufferSize>
T CircleBuffer<T, t_bufferSize>::pull() {
	if (m_count == 0)
		throw std::exception("buffer empty");
	T val = m_buffer[m_readIndex];
	m_readIndex++;
	if (m_readIndex == t_bufferSize)
		m_readIndex = 0;
	m_count--;
	return val;
}