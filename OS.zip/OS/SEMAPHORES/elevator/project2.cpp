//Elevator Simulation: Threads and Semaphores
//Programmed by Michael Burdick, mxb132730

#include <stdlib.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <semaphore.h>

using namespace std;

sem_t Enter; /*Enter is a semaphore that defines how many people may enter the elevator on the ground floor.
			Everybody wait()s on Enter when they are created ("enter the building"), and every time an empty elevator
			reaches the ground floor, it signal()s Enter seven times, allowing seven people to come in
			*/
sem_t LoadUnload; /*LoadUnload is the only semaphore that the Elevator wait()s on. When the elevator reaches a floor,
				  it wait()s on LoadUnload a number of times equal to the number of people it expects to get off on
				  that floor. When people exit the elevator, they signal() the elevator, until everyone planning on
				  getting off gets off, and the elevator is free to continue
				  */
sem_t Floors[9]; /*The nine Floor semaphores are used to keep people on the elevator. Kept in an array for easy
				 access, every person will wait() on the Floor semaphore corresponding to the floor they want to go
				 to when they come in, and when the elevator reaches that floor, it will signal() that floor's semaphore
				 as many times as there are people wanting to get off on that floor, letting that many people get off
				 */

int floorQueues [9]; //floorQueues holds the number of people in the elevator who want to go to each floor
bool done; //done is a variable that main() uses to tell the elevator to stop

void *Person(void *name){//This function is used by all 49 of the Person threads
	int id = (intptr_t)name; //I sort of cheat a little bit, and use an intptr to pass an int through what is defined by the pthread doc to be a void pointer argument. This is how I store each thread's name
	int floor = rand() % 9;//The person then randomly decides what floor they want to go to

	//printf("Hey, I'm a person! My name is %d, and I wanna go to floor %d\n", name, floor+2);
	int test;//test is just used to hold all of the results from the various semaphore calls. I don't do anything with it, but it could be used for debug purposes
	test = sem_wait(&Enter);//Wait on the elevator to signal Enter, therefore inviting a person to enter the elevator

	printf("Person %d enters elevator to go to floor %d\n", id, floor+2);
	test = sem_post(&LoadUnload);//signal LoadUnload, indicating to the elevator that this person is now on the side of the elevator that they want to be on
	//printf("Now I've told the elevator that I've gotten on\n");

	floorQueues[floor]++;//add one to the queue for the floor that this person wants to go to. This is analogous to pressing the floor button
	//printf("There are now %d people queued to go to floor %d\n", floorQueues[floor], floor+2);

	test = sem_wait(&Floors[floor]);//wait for Floor[floor], the semaphore which is signaled when people may get off on the given floor
	printf("Person %d leaves elevator\n", id);
	test = sem_post(&LoadUnload);//Let the elevator know that I'm on the side of the door I want to be on

	//printf("K, I'm gonna die now\n");
}

void *Elevator(void * unusedButMakespThreadHappy){//pThread wants me to pass a void pointer to the Elevator thread function, but I don't need it for anything, so I just have it
	int test;//test, like for Person, is used to hold the results of semaphore operations.
	while(!done){//the elevator loops through this while loop until main tells it to stop
		for(int q = 0; q < 9; q++){//First, set every value in the floorQueues to 0
			floorQueues[q] = 0;
		}

		printf("Elevator door opens at floor 1\n");//Then, open the doors to the ground floor

		for(int i = 0; i < 7; i++){//signal Enter seven times, inviting seven People to enter the elevator
			test = sem_post(&Enter);
		}
		for(int j = 0; j < 7; j++){//once you've invited seven people in, wait on LoadUnload, thus waiting until all 7 get on before moving
			test = sem_wait(&LoadUnload);
		}
		printf("Elevator door closes\n");//close the elevator doors

		for(int k = 0; k < 9; k++){//for every floor 2-10 (where for floor 2, k = 0, for floor 3, k = 1, and so on)
			if(floorQueues[k] > 0){ //if someone wants to get off on this floor
				printf("Elevator door opens at floor %d\n", k+2);//move to that floor
				for (int j = 0; j < floorQueues[k]; j++){//then signal all of the people that want to get off on this floor, allowing them to move
					test = sem_post(&Floors[k]);
				}

				for(int m = 0; m < floorQueues[k]; m++){//then wait for all of them to finish getting off
					test = sem_wait(&LoadUnload);
				}
				printf("Elevator door closes\n");//then close the doors
			}
		}
	
	}
}

bool testReturn(int i){//testReturn is mostly a debug function, which takes in the return value of a pthread or semaphore action and determines if it succeeded or failed
	if(i != 0){
		printf("Whoopsies, somethin' goofed\n");
		printf("Exiting");
		return true;
	}
	return false;
}

int main(int argc, char **argv){//All main does is create all of the threads and semaphores, and join with them at the end
	pthread_t people [49] = {};//people is an array of all 49 Person threads
	pthread_t elevator;//elevator is obviously a reference to the singular elevator thread
	int test;//test is used to hold the return values of semaphore and thread actions
	done = false;//done represents when the simulation is done, and is used to end the elevator

	for(int q = 0; q < 9; q++){//first, initialize all of the floorQueues to 0
		floorQueues[q] = 0;
	}
	//semaphores need to be initialized before threads, or else threads might wait or signal on semaphores that don't exist yet
	test = sem_init(&Enter, 0, 0);//first, make and test the Enter semaphore
	if(testReturn(test)){
		return -1;
	}

	test = sem_init(&LoadUnload, 0, 0);//then, make and test the LoadUnload semaphore
	if(testReturn(test)){
		return -1;
	}

	for(int s = 0; s < 9; s++){//then, make and test all 9 of the Floor semaphores
		test = sem_init(&Floors[s], 0, 0);
		if(testReturn(test)){
			return -1;
		}
	}

	for(int i = 0; i < 49; i++){//then, create all 49 of the person threads. They're not going to be able to go anywhere without elevator to signal Enter, so its fine to start them first
		test = pthread_create(&people[i], NULL, Person, (void *) (intptr_t) i);
		if(testReturn(test)){
			return -1;
		}
	}

	test = pthread_create(&elevator, NULL, Elevator, NULL);//then, create the elevator thread. Since this thread signals Enter, this is the thread that is going to get the whole simulation going.
	if(testReturn(test)){
		return -1;
	}

	for(int j = 0; j < 49; j++){//Wait for all 49 of the Person threads to finish (that is, reach their floor), before continuing
		pthread_join(people[j], NULL);
	}
	done = true;//set done to true to kill off the elevator

	printf("Simulation done\n");//signal the end of the simulation

	return 0;//then finish
}




