# unix-semaphores
program to handle hotel reservations requested by customers at different locations connected to the hotel's database
hw2edf is not relative edf

read the pdf for more information
