### Proccess communication & synchronization via mutexes.

#### This project is about making a restaurant simulation.

Doorman waits for customers and checks if there is a free and suitable table according to the customer group needs.If yes the doorman places them to the suited table otherwise check the (fifo) queue to see if there is another group that can sit.
The waiters go to their corresponding tables when customer group arrives.When meal finished the same waiter brings the bill and the table gets freed.

