#ifndef _Producer_H
#define _Producer_H

// Producer produces content
void *prod_runner(void *arg);

#endif