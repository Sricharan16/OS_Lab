# semaphores
C++, semaphores, shared memory, multiprocess, fork()
