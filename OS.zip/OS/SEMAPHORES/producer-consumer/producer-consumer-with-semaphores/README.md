producer-consumer-with-semaphores example
=================================
