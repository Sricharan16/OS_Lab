#!/bin/bash
make
./run