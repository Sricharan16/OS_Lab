# CSemaphoreMultithreading
Project 2 for Operating Systems Concepts class concerning Semaphores/multithreading using hotel as analogy.

g++ project2.cpp -lpthread