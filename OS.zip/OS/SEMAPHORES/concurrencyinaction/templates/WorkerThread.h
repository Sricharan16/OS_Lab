#pragma once

#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>

#include "globals.h"


using std::mutex;
using std::unique_lock;
using std::condition_variable;
using std::queue;

//readinfile, writeoutfile,
enum class JobType {redrawBubble, quitEverything};

struct WorkJob {
	JobType type;
	SpecificBubbleInWindow bubbleInWindow;
};

class WorkerThread {
	static queue<WorkJob>     sJobs;
	static mutex              sWorkQueueMutex;
	static condition_variable sNewWorkHasArrived;
	bool& mDoQuit;
public:
	WorkerThread(bool& doquit) : mDoQuit(doquit) {};
	void operator()();
	static void addTaskToQueue(WorkJob &job);
};

