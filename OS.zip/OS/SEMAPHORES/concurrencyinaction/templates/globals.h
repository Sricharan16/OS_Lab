#pragma once

#include <map>
#include <string>

//#include "include/selene.h"
#include "SkColor.h"
//#include "Filesystem.h"

extern int controlKeysDown;

using BubbleId = int;
using WindowId = int;

#include <utility>
using SpecificBubbleInWindow = std::pair<BubbleId, WindowId>;

const double PI  = 3.141592653589793238463;

/* the following is from http://stackoverflow.com/questions/81870/is-it-possible-to-print-a-variables-type-in-standard-c */

// use it like:
//    cout << "thing's type is: "<< type_name<decltype( thing )>() << '\n';

#include <type_traits>
#include <typeinfo>
#ifndef _MSC_VER
    #include <cxxabi.h>
#endif
#include <memory>
#include <string>
#include <cstdlib>

template <class T>
std::string type_name() {
    typedef typename std::remove_reference<T>::type TR;
    std::unique_ptr<char, void(*)(void*)> own
           (
#ifndef _MSC_VER
                abi::__cxa_demangle(typeid(TR).name(), nullptr,
                                           nullptr, nullptr),
#else
                nullptr,
#endif
                std::free
           );
    std::string r = own != nullptr ? own.get() : typeid(TR).name();
    if (std::is_const<TR>::value)
        r += " const";
    if (std::is_volatile<TR>::value)
        r += " volatile";
    if (std::is_lvalue_reference<T>::value)
        r += "&";
    else if (std::is_rvalue_reference<T>::value)
        r += "&&";
    return r;
}

#define BOLD      << "\033[1m" 
#define ITALIC    << "\033[3m" 
#define UNDERLINE << "\033[4m" 
#define NORMAL    << "\033[0m" 

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Waddress"

#define show_type(...) std::cout << "Variable " BOLD UNDERLINE << #__VA_ARGS__ NORMAL << " is of type " ITALIC << type_name<decltype( __VA_ARGS__ )>() NORMAL << std::endl;

#pragma GCC diagnostic pop
