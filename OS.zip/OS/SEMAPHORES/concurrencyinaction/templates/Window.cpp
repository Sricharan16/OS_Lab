//int Window::uploadsWaiting = 0;


