#include "GapBuffer.h"




template <class T>
void GapBuffer<T>::boop() {;}

