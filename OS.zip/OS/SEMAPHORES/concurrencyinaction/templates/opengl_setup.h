#pragma once

#ifdef __APPLE__
//#include <OpenGL/gl3.h>
	#define GLFW_INCLUDE_GLCOREARB
#else
	#include "GL/glew.h"
#endif

#include "GLFW/glfw3.h"

void opengl_setup_init_GLFW();
GLint opengl_setup_load_shader_program();
void opengl_setup_shader_program_inputs(GLint shaderprogramid);
int LoadShaders(const char * vertex_file_path,const char * fragment_file_path);
