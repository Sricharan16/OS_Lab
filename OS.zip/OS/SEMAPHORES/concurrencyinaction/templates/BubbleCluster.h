#pragma once

#include <vector>

#include "Bubble.h"

struct BubbleCluster {	
	SkRect                perimeter; // in workspace coords, ie millimetres
	std::vector<BubbleId> members;
};



