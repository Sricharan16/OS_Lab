#pragma once

#include "BubbleCluster.h"

#include <mutex>
#include <queue>
#include <utility>

using std::pair;
using std::mutex;
using std::queue;
using std::vector;

class AllOpenBubbles {
 public:
  vector<Bubble>       bubbles;
  vector<BubbleCluster>  clumps;
	

  mutex  mRedrawQueueBarrier;
  queue< SpecificBubbleInWindow > mRedrawQueue;


};


