#include "Monitors.h"
#include <iostream>
#include <string>
using std::cout;
using std::endl;

void Monitors::discover() {
	mMonitors.resize(0);

	int  count;
	auto monitors = glfwGetMonitors(&count);

	cout<<"hi! "<<count<<endl;
	int leftEdgePositionInScreenUnits, topEdgePositionInScreenUnits,
		widthInMM, heightInMM;

	for (int i = 0; i < count; ++i) {
		glfwGetMonitorPos(monitors[i], &leftEdgePositionInScreenUnits, &topEdgePositionInScreenUnits);
		glfwGetMonitorPhysicalSize(monitors[i], &widthInMM, &heightInMM);
		const GLFWvidmode* mode = glfwGetVideoMode(monitors[i]);

		const char* name = glfwGetMonitorName(monitors[i]);

		mMonitors.emplace_back(widthInMM, heightInMM,
			mode->width, mode->height,
			leftEdgePositionInScreenUnits, topEdgePositionInScreenUnits,
			std::string(name)
			);
	}
}

