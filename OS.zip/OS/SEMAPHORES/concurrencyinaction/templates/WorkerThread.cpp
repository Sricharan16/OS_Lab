#include "WorkerThread.h"

#include "WindowCollection.h"
#include "AllOpenBubbles.h"

#include <iostream>
using std::cout;
using std::endl;

queue<WorkJob>     WorkerThread::sJobs;
mutex              WorkerThread::sWorkQueueMutex;
condition_variable WorkerThread::sNewWorkHasArrived;

void WorkerThread::addTaskToQueue(WorkJob &job) {
	unique_lock<mutex> l(sWorkQueueMutex);
	sJobs.push(job);

	l.unlock();
	sNewWorkHasArrived.notify_one();
}

void WorkerThread::operator()() {
  cout << "Hi from worker thread " << std::this_thread::get_id() <<" !"<<endl;

	while ( ! mDoQuit) {
		unique_lock<mutex> l(sWorkQueueMutex);
//		l.lock();
		sNewWorkHasArrived.wait(l, [](){return ! sJobs.empty();} );
		// make sure to guard against spurious restarts; should just wait again...
		WorkJob job = sJobs.front();
		sJobs.pop();
		l.unlock();

		if (job.type == JobType::quitEverything) {
		  cout <<"Quitting time from thread " << std::this_thread::get_id()<<endl;
			return;
		}
		else if (job.type == JobType::redrawBubble) {
			// marks bubble as redrawn, then what?
		} else {
			cout << "Unknow JobType" << endl;
		}
		//process work here

	}
}

