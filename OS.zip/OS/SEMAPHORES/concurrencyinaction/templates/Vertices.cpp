#include <iostream>

#include "Vertices.h"

GLint VertexGroup::maximum_simultaneous_textures = 8;

void verttest() {
	Vertex v(3.0f,33.0f,3.0f,static_cast<GLint>(1),1.0f,1.0f,(uint8_t)200,(uint8_t)200,(uint8_t)200,(uint8_t)200);
	std::cout<<"Test vertex "<<v.x<<'\n';
}

