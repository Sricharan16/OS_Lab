#pragma once

#include <vector>

#include "SkImageInfo.h"
#include "SkSurface.h"

class Image {
// my linux machine refuses to create RGBA skia surfaces, but will allow BGRA ones
// my macbook is the opposite
// i have no idea if i'm compiling skia wrong or it's about endianness or what
// anyway so create a test image first and then always create those, and tell OpenGL to expect pixels in that order...
	static bool mUseBGRA;
	int mHeightInMM;
	int mWidthInMM;
	
public:
	static bool discoverBGRAvsRGBA();


};

