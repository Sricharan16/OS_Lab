#pragma once

#include <vector>

#ifdef __APPLE__
//#include <OpenGL/gl3.h>
#define GLFW_INCLUDE_GLCOREARB
#else
#include "GL/glew.h"
#endif

#include "GLFW/glfw3.h"

struct Vertex {
	float x;
	float y;
	float z;
	GLint texunit;
	float u;
	float v;
	uint8_t r;
	uint8_t g;
	uint8_t b;
	uint8_t a;
	
	Vertex(float _x, float _y, float _z,
		GLint _texunit, float _u, float _v,
		uint8_t _r,	uint8_t _g,	uint8_t _b, uint8_t _a)
		: x(_x), y(_y), z(_z),
		texunit(_texunit), u(_u), v(_v),
		r(_r), g(_g), b(_b), a(_a)
		{ }
};

void verttest();

class VertexGroup {
	std::vector<Vertex> mTexturedTriangles;
public:
	static GLint maximum_simultaneous_textures;

};
