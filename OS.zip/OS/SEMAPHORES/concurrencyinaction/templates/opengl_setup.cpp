#include "opengl_setup.h"

//#ifdef __APPLE__

//#define GLFW_INCLUDE_GLCOREARB
//#include <OpenGL/gl3.h>
//#else
//#include "GL/glew.h"
//#endif

//#include "GLFW/glfw3.h"

#include <iostream>
#include <string>
#include "Vertices.h"

void glfw_error_callback(int error, const char* description) {
	std::cout << "GLFW error "<<error<<" : " << description << std::endl;
}

void opengl_setup_init_GLFW() {
	if (!glfwInit()) {
		std::cout << "Failed to initialize GLFW.\n";
		exit(-1);
	}

	glfwSetErrorCallback(glfw_error_callback);

//	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); 
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
}

GLint opengl_setup_load_shader_program() {

    glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &VertexGroup::maximum_simultaneous_textures);

    if (VertexGroup::maximum_simultaneous_textures >= 32)
    	VertexGroup::maximum_simultaneous_textures = 32;
    else if (VertexGroup::maximum_simultaneous_textures >= 16)
    	VertexGroup::maximum_simultaneous_textures = 16;
    else VertexGroup::maximum_simultaneous_textures = 8;

	std::string fragment_shader_name = "shader/imagequad" + std::to_string(VertexGroup::maximum_simultaneous_textures) + ".frag";

	return LoadShaders("shader/imagequad.vert", fragment_shader_name.c_str());
}

void opengl_setup_shader_program_inputs(GLint shaderProgramId) {
		int posa = glGetAttribLocation(shaderProgramId, "position");
		glEnableVertexAttribArray(posa);
		glVertexAttribPointer(posa, 3, GL_FLOAT, GL_FALSE, 28, 0);

		int texid = glGetAttribLocation(shaderProgramId, "texunit");
		glEnableVertexAttribArray(texid);
		glVertexAttribPointer(texid, 1, GL_INT, GL_FALSE, 28, (void*)12);

		int texaco = glGetAttribLocation(shaderProgramId, "texcoord");
		glEnableVertexAttribArray(texaco);
		glVertexAttribPointer(texaco, 2, GL_FLOAT, GL_FALSE, 28, (void*)16);

		int cola = glGetAttribLocation(shaderProgramId, "color");
		glEnableVertexAttribArray(cola);
		glVertexAttribPointer(cola, 4, GL_UNSIGNED_BYTE, GL_TRUE, 28, (void*)24);
}

// copied from http://www.opengl-tutorial.org/
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

int LoadShaders(const char * vertex_file_path, const char * fragment_file_path){

	// Create the shaders
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);

	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	// Read the Vertex Shader code from the file
	std::string VertexShaderCode;
	std::ifstream VertexShaderStream(vertex_file_path, std::ios::in);
	if(VertexShaderStream.is_open()){
		std::string Line = "";
		while(getline(VertexShaderStream, Line))
			VertexShaderCode += "\n" + Line;
		VertexShaderStream.close();
	}else{
		printf("Unable to open shader program: %s\nMake sure the binary executable is located in the release directory!\n", vertex_file_path);
//		getchar();
		return 0;
	}

	// Read the Fragment Shader code from the file
	std::string FragmentShaderCode;
	std::ifstream FragmentShaderStream(fragment_file_path, std::ios::in);
	if(FragmentShaderStream.is_open()){
		std::string Line = "";
		while(getline(FragmentShaderStream, Line))
			FragmentShaderCode += "\n" + Line;
		FragmentShaderStream.close();
	}

	GLint Result = GL_FALSE;
	int InfoLogLength;

	// Compile Vertex Shader
	std::cout<<"Compiling shader : "<< vertex_file_path<<endl;
	char const * VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer , NULL);
	glCompileShader(VertexShaderID);

	// Check Vertex Shader
	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if ( InfoLogLength > 0 ){
		std::vector<char> VertexShaderErrorMessage(InfoLogLength+1);
		glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &VertexShaderErrorMessage[0]);
		std::cout<< &VertexShaderErrorMessage[0]<<endl;
	}

//cout<<"SHEANRE???"<<endl;

	// Compile Fragment Shader
	std::cout<<"Compiling shader : "<< fragment_file_path<<endl;
	char const * FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer , NULL);
	glCompileShader(FragmentShaderID);

	// Check Fragment Shader
	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if ( InfoLogLength > 0 ){
		std::vector<char> FragmentShaderErrorMessage(InfoLogLength+1);
		glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &FragmentShaderErrorMessage[0]);
	std::cout << &FragmentShaderErrorMessage[0]<<endl;
	}

	// Link the program
	std::cout<<"Linking program\n"<<endl;
	GLuint ProgramID = glCreateProgram();
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);

	// Check the program
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if ( InfoLogLength > 0 ){
		std::vector<char> ProgramErrorMessage(InfoLogLength+1);
		glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ProgramErrorMessage[0]);
		std::cout << &ProgramErrorMessage[0]<<endl;
	}

	glDetachShader(ProgramID, VertexShaderID);
	glDetachShader(ProgramID, FragmentShaderID);
	
	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);
std::cout<<"her99e"<<std::endl;

	return ProgramID;
}
