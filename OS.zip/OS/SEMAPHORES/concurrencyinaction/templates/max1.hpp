#include <iostream>

template<typename T>
T max (T a, T b) {
	std::cout <<"int s "<<sizeof(int);
	static_assert(sizeof(int) < 10, "int too small");
	// if b < a then yield a else yield b
	return b < a ? a : b;
}