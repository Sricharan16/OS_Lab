//#define CATCH_CONFIG_MAIN
//#include "catch.hpp"

// https://github.com/catchorg/Catch2/blob/master/docs/own-main.md#top
#define CATCH_CONFIG_RUNNER
#include "catch.hpp"


#include "opengl_setup.h"



int main( int argc, char* argv[] ) {
  // global setup...

	// init glfw here...
	opengl_setup_init_GLFW();

  int result = Catch::Session().run( argc, argv );

  // global clean-up...

  //shutdown glfw here...
  
	glfwTerminate();

  return result;
}