#include "RenderThread.h"

#include <iostream>       // std::cout, std::endl
#include <thread>         // std::this_thread::sleep_for
#include <chrono>         // std::chrono::seconds
#include <vector>

#include "WorkerThread.h"

void RenderThread::operator()() {

	//for each window in the collection
	//draw a rotating triangle in the center
	//wait 16 ms or so


// this_thread::sleep_for example
 
	std::vector< std::pair <BubbleId, WindowId> > uploadQueue;
//int main() 
	std::cout << "countdown:\n";
	auto start = std::chrono::high_resolution_clock::now();
	int  i = 0;

	while (!doquit) {
//		rerender = false;
		start = std::chrono::high_resolution_clock::now();
		++i;

		windows.uploadQueueBarrier.lock();
		try {
			if (! windows.uploadQueue.empty()) {
				uploadQueue.swap(windows.uploadQueue);
			}
		    windows.uploadQueueBarrier.unlock();
		} catch (...) {
		    windows.uploadQueueBarrier.unlock();
		}
		
		std::cout<<"hi";

		uploadImages(uploadQueue);
		uploadQueue.clear();


		// nobody gets to alter any geometry while we're doing this, as they may alter something we've already drawn and then at the end when we mark everything up to date that'll be wrong
		// i have no idea what i'm doing
		geometryFlagBarrier.lock();
		try {			
			if (workspaceGeometryChanged) {

				// if bubbles have moved
					// regenerate panning bar
					// check if they're visible in each of the windows, if so:
						// generate halo geometry
						// request they supply tack texture coords onto the end of our vert gathering



	//			screen areas or resolution or window position or 

//rerender, reupload
//put requests for redraws onto the work queue


			}
			geometryFlagBarrier.unlock();
		} catch (...) {
		    geometryFlagBarrier.unlock();
		}

		
		// lock the windows list
		// for each window:
			// check for animations
			// if textures are stale
			// if geometry is stale is stale
				// regenerate geometry
				// re-upload geometry
				// re-render geometry
//    std::cout << i << std::endl;
		std::this_thread::sleep_until(start + std::chrono::milliseconds(16));
	}
}

// if window centers or sizes have changed, or bubbles have moved, go through every bubble and check if it appears in every window


void RenderThread::uploadImages(std::vector<std::pair<int,int>> uploadQueue) {
	mMarshallBubblesWithImagesForUpload.resize(windows.size());
	mMarshallBubblesWithImagesForUpload.clear();
	for (auto& p : uploadQueue) {
		mMarshallBubblesWithImagesForUpload[p.second].push_back(p.first);
	}
	uploadQueue.clear();
}
