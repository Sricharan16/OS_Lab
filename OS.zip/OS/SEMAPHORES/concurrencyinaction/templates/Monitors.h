#pragma once

#include <vector>
using std::vector;

#ifdef __APPLE__
//#include <OpenGL/gl3.h>
	#define GLFW_INCLUDE_GLCOREARB
#else
	#include "GL/glew.h"
#endif

#include "GLFW/glfw3.h"

#include <iostream>
using std::cout;
using std::endl;
#include <string>
using std::string;

struct Monitor {
	Monitor() {
		cout<<"Constructed empty monitor record"<<endl;
	};
	Monitor(int wMM, int hMM, int wSU, int hSU, int pX, int pY, string n) : widthInMM(wMM), heightInMM(hMM),
		widthInScreenUnits(wSU), heightInScreenUnits(hSU),
		xPosInScreenUnits(pX), yPosInScreenUnits(pY), name(n) {
		cout<<"Constructed pre-filled-in monitor record"<<endl;

		}; 
	const int widthInMM {410};
	const int heightInMM {200};
	const int widthInScreenUnits {1280}; // screen units
	const int heightInScreenUnits {1024};
	const int xPosInScreenUnits {0};
	const int yPosInScreenUnits {0};
	const string name;
};

class Monitors {
	vector<Monitor> mMonitors {};
public:
	void discover();
	Monitor& getMeasurements(int id) {return mMonitors[id];};
	size_t count() {mMonitors.size();};
};


