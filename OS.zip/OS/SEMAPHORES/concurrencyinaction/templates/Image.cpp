#include "Image.h"

#include <iostream>

bool Image::mUseBGRA;

bool Image::discoverBGRAvsRGBA() {
	SkImageInfo testpixelinfo = SkImageInfo::Make(1, 1, 
//		kN32_SkColorType, // crash linux, safe mac
		kRGBA_8888_SkColorType,  // crash linux, safe mac
//		kBGRA_8888_SkColorType,    //safe linux, mac crash

		kPremul_SkAlphaType
//		kOpaque_SkAlphaType
	);

	size_t rowBytes = testpixelinfo.minRowBytes();
	size_t mSize = testpixelinfo.getSafeSize(rowBytes);
    std::vector<char> testpixelMemory;
	testpixelMemory.resize(mSize);  // allocate memory

	sk_sp<SkSurface> testpixelsurface = 
		SkSurface::MakeRasterDirect(testpixelinfo, &testpixelMemory[0], rowBytes);

	if (testpixelsurface != 0)
		return mUseBGRA = false;

	testpixelinfo = SkImageInfo::Make(1, 1, 
//		kN32_SkColorType, // crash linux, safe mac
//		kRGBA_8888_SkColorType,  // crash linux, safe mac
		kBGRA_8888_SkColorType,    //safe linux, mac crash

		kPremul_SkAlphaType
//		kOpaque_SkAlphaType
	);	

	testpixelsurface = 
		SkSurface::MakeRasterDirect(testpixelinfo, &testpixelMemory[0], rowBytes);

	if (testpixelsurface != 0) 
		return mUseBGRA = true;

	std::cout << "Neither RGBA nor BGRA skia canvasses can be created :(" << std::endl;
	return false;
}

