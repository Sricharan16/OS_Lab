//https://solarianprogrammer.com/2012/05/09/cpp-11-thread-tutorial-part-3/
#include <iostream>
#include <thread>
#include <string>

using namespace std;

class SaylHello{
public:

  //This function will be called from a thread
  void func(const string &name) {
     cout <<"Hello " << name << endl;
  };
};

int main(int argc, char* argv[])
{
  SaylHello x;

  //Use a member function in a thread
  thread t(&SaylHello::func, &x, "Tom");

  //Join the thread with the main thread
  t.join();

  return 0;
}

///|||||##################################################################################


#include <iostream>
#include <thread>
#include <string>

using namespace std;

int main(int argc, char* argv[])
{
  //Use of an anonymous function (lambda) in a thread
  thread t( [] (string name) {
    cout << "Hello " << name << endl;
  }, "Tom");

  //Join the thread with the main thread
  t.join();

  return 0;
}

2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_m2repository_r47.zip
https://dl.google.com/android/repository/android_
///|||||##################################################################################

///|||||##################################################################################

/*
bad graphics: http://bogleech.tumblr.com/post/166677275133/fan-support-dunkey

recursive / timed mutexes, condition variables:
https://baptiste-wicht.com/posts/2012/04/c11-concurrency-tutorial-advanced-locking-and-condition-variables.html

http://thispointer.com/c11-multithreading-part-7-condition-variables-explained/

http://thispointer.com/c11-multithreading-part-3-carefully-pass-arguments-to-threads/
	Even if threadCallback accepts arguments as reference but still changes done it are not visible outside the thread.
	Its because x in the thread function threadCallback is reference to the temporary value copied at the new thread’s stack.




*/

//kvm for accelerated android emulation under linux
//https://developer.android.com/studio/run/emulator-acceleration.html?utm_source=android-studio#vm-linux







