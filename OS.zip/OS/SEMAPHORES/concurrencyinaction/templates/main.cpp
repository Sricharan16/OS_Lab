#include <iostream>
#include <typeinfo>
#include <vector>
#include "max1.hpp"

#include <thread>

//#define CATCH_CONFIG_MAIN
#include "catch.hpp"

//#include "GL/glew.h

#define NDEBUG

#ifdef _WIN32
	#ifndef NDEBUG
		#include <windows.h>
	#endif
#endif

#include "SkData.h"

#include "SkImage.h"

#include "SkImageInfo.h"
#include "SkStream.h"
#include "SkSurface.h"
#include "SkCanvas.h"
#include "SkGraphics.h"
#include "SkColor.h"

#include <functional>
#include <mutex>
#include <vector>

//using namespace std;
using std::cout;
using std::endl;
using std::vector;
using std::string;
using std::mutex;

#include "Configuration.h"

#include "opengl_setup.h"
//#include "WindowCollection.h"
#include "RenderThread.h"

#include "globals.h"

#include "Image.h"

static bool gDoQuit {false};


#include "WorkerThread.h"

#include "GapBuffer.h"


int main () {
	#ifdef _WIN32
		#ifndef NDEBUG
			FreeConsole();
		#endif
	#endif

	opengl_setup_init_GLFW();


	vector <int> nums = {1,2,3,4};
	cout << "humber: "<< nums[2]<<endl;

	GapBuffer<int> g {};


	vector<int> boop (10);
	
	cout << "gb " << boop.size()<<endl;//g << endl;
	

	g.insertElement(0);
	g.insertElement(1);
	g.insertElement(2);
	g.insertElement(3);
	g.insertElement(4);
	g.moveGap(1);
		cout<<"true size "<<g.actualSize()<<endl;
		g.insertElement(23);
		g.insertElement(46);
		g.insertElement(69);		g.insertElement(101);
 		g.insertElement(102);
 		g.insertElement(103);

		g.print();

		for (int i = 0; i<g.size(); i++)
			cout<<". "<<*g.pointerToElement(i)<<endl;

	cout << "ac "<< g.size() << endl;
	exit(0);

	
	WindowCollection windows;
	windows.openNewWindow();
	windows.openNewWindow(0);
	show_type(windows);
	AllOpenBubbles bubbles;

	bool workspaceGeometryChanged {true};
	mutex changedGeometrySemaphorBarrier;

	WorkerThread w1(::gDoQuit);
	WorkerThread w2(::gDoQuit);
	vector<std::thread> workers;
	workers.push_back(std::thread(w1));
	workers.push_back(std::thread(w2));
	WorkJob j1{JobType::quitEverything};
	WorkJob j2{JobType::quitEverything};
	WorkerThread::addTaskToQueue(j2);
	WorkerThread::addTaskToQueue(j1);
cout<<"worker threads remaining : "<<workers.size()<<endl;

// std::ref( ) 's here???
	RenderThread renderLoop(windows, bubbles, workspaceGeometryChanged, changedGeometrySemaphorBarrier, ::gDoQuit);
    std::thread  renderThread(renderLoop);
//    auto renderThread = std::thread(&RenderThread::RenderThread, (windows), (bubbles), (::gDoQuit));


//	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // To make MacOS happy
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	GLFWwindow* window = glfwCreateWindow(640, 480, "My Title", NULL, NULL);

	

	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);

			int x,y;
		glfwGetWindowPos(window, &x, &y);
//		glfwGetFramebufferSize(window, &x,&y);
	int width = 100, height = 100;

	SkGraphics::Init();

	// my linux machine refuses to  create RGBA skia surfaces, but will allow BGRA ones
	// my macbook is the opposite
	// i have no idea if i'm compiling skia wrong or it's about endianness or what
	// anyway so create a test image first and then always create those, and tell OpenGL to expect pixels in that order...

	bool useBGRA = Image::discoverBGRAvsRGBA();

	if (useBGRA)
		cout<<"BGRA CANVASSES ALLOWED";
	else
		cout<<"RGBA CANVASSES ALLOWED";

	Configuration config {};

	sel::State luaInterpreterState{true};
	luaInterpreterState("os = nil; io = nil; package = nil; debug = nil; require = nil");
	// would be better to start an environment without *any* standard libraries and only add stuff as needed, but unsure how to do that

	config.load_user_settings(luaInterpreterState);

string key = "hii";
cout<<"NUMBAR "<<config.number("hii")<<endl;


	cout<<"aa"<<endl;
	SkImageInfo info = SkImageInfo::Make(width, height, 

//kN32_SkColorType, // crash linux, safe mac
//kRGBA_8888_SkColorType,  // crash linux, safe mac
//kBGRA_8888_SkColorType,    //safe linux, mac crash

(useBGRA ? kBGRA_8888_SkColorType : kRGBA_8888_SkColorType) ,  

kPremul_SkAlphaType
//kOpaque_SkAlphaType
);


	cout<<"bb "<<(&info)<<endl;
	cout<<"33 "<<endl;

    std::vector<char> mPixelMemory;
   	sk_sp<SkSurface> mSkSurface;
	cout<<"88"<<endl;

     size_t rowBytes = info.minRowBytes();
     size_t mSize = info.getSafeSize(rowBytes);
// //     cout << "widht: "<<width<<"    "<<width*height*4<<"     size: "<<mSize<<"     rowbytes: "<<rowBytes<<endl;
     mPixelMemory.resize(mSize);  // allocate memory
     cout <<"sz "<<mPixelMemory.size()<<"   rb "<<rowBytes<<"   ms "<<mSize<<endl;
     mSkSurface = 
               SkSurface::MakeRasterDirect(
                      info, &mPixelMemory[0], rowBytes);
 	cout<<"77 " << mSkSurface << endl;


    std::vector<char> mPixetaw;
     mPixetaw.resize(mSize);  // allocate memory
   	

 	auto ug = mSkSurface;
 	cout<<"bbb "//<<type_name<decltype( ug )>()
 	<<"  "<<ug<<endl;// MUST NOT BE NULLL
 	SkCanvas* canvas = ug->getCanvas();


 	cout<<"canvars " <<canvas<<endl;
 	cout<<"99 "<<kBGRA_8888_SkColorType << " "<<kRGBA_8888_SkColorType<<" "<<kN32_SkColorType<< endl;

     const char* path = "hi.png";
    

    canvas -> clear(SK_ColorRED);


	while (!glfwWindowShouldClose(window)) {
		glfwSwapBuffers(window);
		glfwPollEvents(); // need to call this before it will appear on mac os
	}

	glfwDestroyWindow(window);

	glfwTerminate();

	gDoQuit = true;

	renderThread.join();
}
