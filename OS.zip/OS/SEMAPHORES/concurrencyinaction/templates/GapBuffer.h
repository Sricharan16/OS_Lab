#pragma once

#include <vector>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>


using std::vector;
using std::cout; using std::endl;

#include <string>

template <class T>
class GapBuffer {
	vector<T> myElements;
	int myGapStart {0};
	int myGapSize {0};
public:
	int gapIndex() {return myGapStart;};
	void boop();
	void moveGap   (int ind) {
		int count = abs(ind - myGapStart);
		int size = sizeof(T);
		T*  data = myElements.data();
		
		if (ind == myGapStart)
			return;
		if (ind < myGapStart) {// move stuff to end of gap
			memmove( &myElements[myGapStart + myGapSize - count], &myElements[ind]            , count * size);
		} else {
			memmove( &myElements[myGapStart],                    &myElements[ind + myGapSize] , count * size);
		}
		myGapStart = ind;
	};
	void insertElement(T thing) {
		int bufferSize = myElements.size();
		if (myGapSize == 0) {
			int newsize = ceil((1 + bufferSize) * 1.25);
			myElements.resize(std::max(4, newsize));
			// gap is now effectively at back of buffer
			int oldGapPosition = myGapStart;
			myGapStart = bufferSize;
			myGapSize = myElements.size() - bufferSize;
			moveGap(oldGapPosition);
		}
		myElements[myGapStart] = thing;
		++ myGapStart;
		-- myGapSize;
	};
	void deleteElement() {--myGapStart; ++myGapSize;};
	void deletePointerElement() {};
	void overwriteElement(T thing) {myElements[myGapStart - 1] = thing;};
	T*   pointerToElement() {return myElements.data() + (myGapStart - 1) * sizeof(T);};
	T*   pointerToElement(int ind) {
		if (ind < myGapStart) {
			return &myElements[ind];
		}
		return &myElements[ind + myGapSize];
	}
	int size() {return myElements.size() - myGapSize;};
	int actualSize() {return myElements.size();};
	void print() {
		cout<<endl;
		for (int i = 0; i < myElements.size(); i++){
			if (i >= myGapStart && i < myGapStart + myGapSize) {
				cout<< "-- "<<myElements[i]<<endl;;
				continue;
			}
			
			cout<<"   "<<myElements[i]<<endl;
		}
		cout<<endl;
	}
};



template <class T>
std::ostream &operator<<(std::ostream &os, GapBuffer<T> const &m) {
	for (int i = 0; i < m.size(); i++) {
		os << m[i];
		if (i != m.size() - 1)
			os << ", ";
	}
    return os;
}
