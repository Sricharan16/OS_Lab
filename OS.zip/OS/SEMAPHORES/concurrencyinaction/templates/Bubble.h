#pragma once

#include "SkRect.h"

#include "globals.h"

struct Bubble {
  SkRect   position; // in workspace coords, ie millimetres
  BubbleId id;
  
  
};
