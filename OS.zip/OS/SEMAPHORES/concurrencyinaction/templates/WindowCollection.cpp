#include "WindowCollection.h"

#include <string>
#include <iostream>

#include "Vertices.h"
#include "opengl_setup.h"

// GLint WindowCollection::mShaderProgramId = 1;

WindowId WindowCollection::openNewWindow(WindowId parent) {
	GLFWwindow* pNewWindow;

	if (mWindows.empty()) {
		pNewWindow = glfwCreateWindow( 1024, 768, "Window 1", NULL, NULL);
		glfwMakeContextCurrent(pNewWindow);

		#ifndef __APPLE__
			glewExperimental = true; // Needed for core profile
			if (glewInit() != GLEW_OK) {
				std::cout << "Failed to initialize GLEW\n";
			//	glfwTerminate();
			}
		#endif

		int major=0; int minor=0;
		glGetIntegerv(GL_MAJOR_VERSION, &major);
		glGetIntegerv(GL_MINOR_VERSION, &minor);
		std::cout << "OpenGL version " << major << "."<<minor<<'\n';

		mShaderProgramId = opengl_setup_load_shader_program();
	}
	else {
		std::string title = "Window " + std::to_string(mWindows.size() + 1);

		GLFWwindow* pParentWindow = mWindows[parent].pGLFWwindow;

		pNewWindow = glfwCreateWindow( 1024, 768, title.c_str(), glfwGetWindowMonitor(pParentWindow), pParentWindow);
		glfwMakeContextCurrent(pNewWindow);

		int x, y;
		glfwGetWindowPos(pParentWindow, &x, &y);
		glfwSetWindowPos(pNewWindow, x+50, y+50);
	}

	if ( ! pNewWindow) {
		std::cout << "\nFailed to open GLFW window, try updating graphics drivers?\nOpenGL version 3.2 or higher is required.";
		glfwTerminate();
		exit(-1);
	}

	glUseProgram(mShaderProgramId);

	for (int n = 0; n < VertexGroup::maximum_simultaneous_textures; ++n)
		glUniform1i(glGetUniformLocation(mShaderProgramId,
										 std::string("tex"+std::to_string(n)).c_str()), n);

	GLint windowId = mWindows.size();

	mWindows.emplace_back(Window{pNewWindow});

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wint-to-pointer-cast"
	glfwSetWindowUserPointer(pNewWindow, (void*) (windowId));
#pragma GCC diagnostic push pop

	return windowId;
}

