#pragma once

#include <vector>

#include "Window.h"

#include "globals.h"

using std::mutex;
using std::vector;
using std::pair;

struct WindowCollection {
    GLint                                        mShaderProgramId;
	vector<Window>                          mWindows;

	mutex                                   modificationsToWindowList;
	mutex                                   uploadQueueBarrier;
	vector< pair <BubbleId, WindowId> > uploadQueue {};
	WindowId openNewWindow(WindowId parent = -1);

	Window& get(WindowId id) { return mWindows[id]; }
	size_t size() {return mWindows.size();}
};
