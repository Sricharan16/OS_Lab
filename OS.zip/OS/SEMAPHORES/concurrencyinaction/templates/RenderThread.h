#pragma once

#include "WindowCollection.h"
#include "AllOpenBubbles.h"

#include <mutex>
#include "globals.h"

class RenderThread {
	// bool mDoRerenderEverything;
	// bool mTexturesChanged;
	// bool mMouseMovedOverPanningBar;


	WindowCollection& windows;
	AllOpenBubbles& bubbles;

	bool& workspaceGeometryChanged;
	std::mutex& geometryFlagBarrier;
	
	bool& doquit;

	std::vector <std::vector <BubbleId> > mMarshallBubblesWithImagesForUpload;

	void uploadImages(std::vector<std::pair<int,int>> uploadQueue);
public:
	RenderThread(WindowCollection& wins
		, AllOpenBubbles& bubs
		, bool& iRerenderEverything 
		, std::mutex& flagBarrier
		, bool& quitit)
			: windows(wins)
			, bubbles(bubs) 
			, workspaceGeometryChanged(iRerenderEverything)
			, geometryFlagBarrier(flagBarrier)
			, doquit(quitit)
		{}
	void operator()();
};


