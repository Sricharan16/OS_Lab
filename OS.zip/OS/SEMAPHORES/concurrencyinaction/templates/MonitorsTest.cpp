#include "catch.hpp"
#include "Monitors.h"
#include <iostream>
using std::cout;
using std::endl;

TEST_CASE("Monitors are discovered") {
	Monitors m;
	m.discover();
	REQUIRE(m.count() > 0);
	cout << "Monitors discovered: " << m.count() << endl;
	auto mm = m.getMeasurements(0);
	cout << mm.name << endl;
}
