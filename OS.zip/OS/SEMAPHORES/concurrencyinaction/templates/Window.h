#pragma once

#ifdef __APPLE__
//#include <OpenGL/gl3.h>
#define GLFW_INCLUDE_GLCOREARB
#else
#include "GL/glew.h"
#endif

#include "GLFW/glfw3.h"

#include "SkPoint.h"

#include <mutex>
#include <queue>

#include "globals.h"

class Window {
	SkIPoint   mPixelSize {1000,1000};
	double     mMMperPixel {25.4 / 90.0};  //reciprocal of dots-per-millimeter
	bool       mHighRes {false};
	SkPoint    mTopLeftCorner_WorkspacePosition {50.0,50.0};
	double     mScale {1.0};


//	SkPoint  mRelativeCenter; // to scale about when zooming in or out
public:
//	static int uploadsWaiting;
	GLFWwindow* pGLFWwindow;
	Window(GLFWwindow* _pGLFWwindow) : pGLFWwindow(_pGLFWwindow) {};

	//glfw handle? / our id number?
	SkPoint sizeInMM() {return SkPoint::Make(mPixelSize.x() * mMMperPixel, mPixelSize.y() * mMMperPixel);}
//	void create_window(int parentId);
};


