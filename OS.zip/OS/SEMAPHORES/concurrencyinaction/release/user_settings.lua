user_settings = {

-- Values set here override those set in the 'default_settings.lua' file

--  ["Menu text size in points"] = 28
--, ["menu text color"]          = grey(0.5)
--,["Linux font"]= "Free Sans"
}