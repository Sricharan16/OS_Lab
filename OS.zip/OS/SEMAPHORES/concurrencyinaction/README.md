Learning about multithread programming using Manning Publishing's book [C++ Concurrency in Action, second edition](https://www.manning.com/books/c-plus-plus-concurrency-in-action-second-edition) and [The Little Book of Semaphores](http://greenteapress.com/wp/semaphores/).

