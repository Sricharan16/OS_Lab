#include <iostream>
#include <thread>
#include <vector>
#include <string>

//#define NDEBUG
#include <cassert>

#include "Testy.h"

using namespace std;

void hello(int n) {
	cout<<"hi "<<n<<endl;
}

string truthy(bool boop) {return boop ? "true" : "false"; }

class background_task {
public:
	void operator()() const {
		cout<<"HEY NONUM;"<<endl;
	}
	void operator()(int i) const {
		cout<<"NUM: "<<i<<endl;
	}
};

int main() {
	cout<<"Threads: "<<thread::hardware_concurrency()<<endl;
	int bop = Testy::hiya();

	vector<thread> v;

	background_task callme;

	for (int i = 0; i<10; i++)
		v.push_back(thread{hello, i});
	thread t2{background_task()};

	cout<<"joinables? "<<truthy(t2.joinable())<<endl;

	for (int i = 0; i<10; i++)
		v[i].join();
	t2.join();
	assert(t2.joinable());
	cout<<"joinables2? "<<truthy(t2.joinable())<<endl;
//	cout<<"hello "<<boop<<endl;

}