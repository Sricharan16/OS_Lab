class Testy {
public:
	static int hiya();
};

