#include "Testy.h"

int Testy::hiya() {
	return 9;
}
