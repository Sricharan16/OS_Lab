# Dining and Driking Philosopher Problem Using Multi-Threading (Mutex & Semaphores). Written in c++.
