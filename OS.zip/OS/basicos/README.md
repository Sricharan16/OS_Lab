# Basic-Operating-System
A simple operating system written in C++. Includes a file system, memory management, priority based thread scheduling, and mutex locks.
