#include "task.hpp"

Task::Task(int digit):
		m_digit(digit){}
int Task::getDigit()
{
	return m_digit;
}
