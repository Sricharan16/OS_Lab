`#Computing Pi with multi Threading

The computePi.hpp and computePi.cpp were not written by me,
I only did the multiThreading. This computes 1000 digit of 
pi in about 4 minutes on a raspberry pi.
