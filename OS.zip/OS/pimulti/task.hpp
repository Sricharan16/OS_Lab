#pragma once


class Task
{
public: 
	Task(int digit);
	int getDigit();

private:
	int m_digit;
};
