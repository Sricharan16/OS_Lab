// James Scott
// Dining Philosophers

#include <cstdio> //needed for perror
#include <iostream>
#include <pthread.h>
#include <cstdlib>
