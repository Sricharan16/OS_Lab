// James Scott
// Dining Savages

#include<cstdio>
#include<iostream>
#include<pthread>
#include<cstdlib>
#include<unistd.h>
using namespace std;

void* eat()
{

}

void* signal()
{

}

int main()
{
	pthread_t savage1, savage2, savage3, sagave4, savage5, savage6, savage7, savage8, savage9, savage10, cook;
	int pot = 10;


	//create threads
	if(pthread_create(&savage1, 0, & ))
}