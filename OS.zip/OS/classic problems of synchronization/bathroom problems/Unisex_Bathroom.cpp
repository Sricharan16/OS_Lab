// James Scott
// Unisex Bathroom

#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<pthread.h>
#include "semp.h"
#include <time.h>
using namespace std;

Semaphore maleS;
Semaphore femaleS;
Semaphore bathroom;
Semaphore multex;

// count, so we can number the processes
int femalen = 1;
int malen = 1;

// count for number in bathroom and waiting
int femaleCount = 0;
int femalesWaiting = 0;
int maleCount = 0;
int malesWaiting = 0;

//instead of passing the id as the parameter, this just uses a global variable and a multex
void *male(void *noparam)
{
	int i;
	int eid;
	int t;
	bool canUse = false;

	// getting the id number
	semaphore_down(&multex);
	eid = malen;
	malen++;
	semaphore_up(&multex);
	printf("male %d: Starting /n", eid);

	while (1 == 1)
	{
		// work for a while
		t = (int)rand() % 10;
		printf("male &d: is working on OpSys for %d seconds /n", eid, t);
		sleep(t);

		printf("male %d: needs to use the bathroom /n", eid);
		sleep(t);

		semaphore_down(&bathroom);
		if (femaleCount == 0) // bathroom has no females, so no waiting
		{
			malesWaiting++;
			semaphore_up(&bathroom);
		}
		else
		{
			malesWaiting++;
			semaphore_up(&bathroom);
			printf("male %d: is line /n", eid);
			semaphore_down(&maleS);	// line of males waiting

			//finally can use the bathroom, mark the count up
			semaphore_down(&bathroom);
			maleCount++;
			semaphore_up(&bathroom);
		}

		// use bathroom
		t = (int)rand() % 10;
		printf("male %d: is using the bathroom for %d seconds /n", eid, t);
		sleep(t);

		semaphore_down(&bathroom);
		maleCount--;
		if (maleCount == 0)
		{
			printf("male %d: signaling the line to start /n", eid);
			for (i = 0; i < femalesWaiting; i++)
			{
				semaphore_up(&femaleS);
				femalesWaiting = 0;
			}
			semaphore_up(&bathroom);
			printf("male %d: is done using the bathroom /n", eid);
		}
	}
}

void *female(void *noparam)
{
	int i;
	int t;
	int eid;

	semaphore_down(&multex);
	eid = femalen;
	femalen++;
	semaphore_up(&multex);
	printf("female %d: Starting /n", eid);

	// initially set to infinite for testing
	while (1 == 1)
	{
		t = (int)rand() % 10;
		printf("female %d: is working on OpSys for %d seconds /n", eid, t);
		sleep(t);

		printf("female %d: needs to use the bathroom /n", eid, t);
		semaphore_down(&bathroom);
		if (maleCount == 0) // empty
		{
			femaleCount++;
			semaphore_up(&bathroom);
		}
		else
		{
			femalesWaiting++;
			semaphore_up(&bathroom);
			printf("female %d: is line /n", eid, t);
			semaphore_down(&femaleS); // the line of females waiting

			// finally can use the bathroom, mark the count up
			// note must do this outside of the bathroom, CR or deadlock will happen
			semaphore_down(&bathroom);
			femaleCount++;
			semaphore_up(&bathroom);
		}
	}

	// use bathroom
	t = (int)rand() % 10;
	printf("female %d: is using the bathroom for %d: seconds /n", eid, t);
	sleep(t);

	// done
	semaphore_down(&bathroom);
	femaleCount--;
	if (femaleCount == 0)
	{
		printf("female %d: signaling the line to start /n", eid, t);
		for (i = 0; i < malesWaiting; i++)
		{
			semaphore_up(&maleS);
			malesWaiting = 0;
		}
		semaphore_up(&bathroom);
		printf("female %d: is done with the bathroom /n", eid, t);
	}
}

main(int argc, char* argv[])
{
	int i;
	// defaults
	int num_m = 1;
	int num_f = 1;

	if (argc == 3)
	{
		num_m = atoi(argv[1]);
		num_f = atoi(argv[2]);
	}
	printf("m is %d: , f is %d: ", num_m, num_f);

	pthread_t males[num_m];
	pthread_t females[num_f];

	srand((unsigned)time(0));

	//init semaphore line to 0, everyone must wait
	semaphore_init(&maleS, 0);
	semaphore_init(&femaleS, 0);
	// init semaphore bathroom to 1, so first person can go in
	semaphore_init(&bathroom, 1);
	// init semaphore multex to 1, so first person can entry critical section
	semaphore_init(&multex, 1);

	//create threads
	for (i = 0; i < num_m; i++)
	{
		if (pthread_create(&males[i], 0, male, 0))
		{
			perror("error creating the thread");
			exit(1);
		}
	}

	printf("male threads created /n");

	for (i = 0; i < num_f; i++)
	{
		if (pthread_create(&females[i], 0, female, 0))
		{
			perror("error creating the thread");
			exit(1);
		}
	}

	printf("all threads created /n");

	// wait for threads to finish
	for (i = 0; i < num_m; i++)
	{
		pthread_join(males[i], 0);
	}
	for (i = 0; i < num_f; i++)
	{
		pthread_join(females[i], 0);
	}
}