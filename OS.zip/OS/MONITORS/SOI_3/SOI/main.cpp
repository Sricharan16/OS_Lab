#include <iostream>
#include <stdio.h>
#include <pthread.h>
#include <deque>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "monitor.h"

#define buf_MAX 9
#define buf_MIN 3
#define sleep_MIN 1000000 //2 sekundy
#define sleep_MAX 4000000 //6 sekund

Semaphore mutex(1), empty(buf_MAX), even(0), odd(0), full(0);
std::deque <unsigned int> bufor;

int setSleep ()  //losuje czas snu konsumentow i producentow
{
	return (rand()%sleep_MAX + sleep_MIN);
}

void consElem(std::string consumer)
{
   std::cout<< consumer<<" "<< *bufor.begin()<< std::endl;;
   bufor.pop_front();
   printf("%d\n", bufor.size()); //ilosc elementow w buforze
   (*bufor.begin() % 2 == 0) ? even.v() : odd.v();
}

void prodElem()
{
  int number = rand()%100+1; //produkuje nowa liczbe od 1 do 100
  bufor.push_back(number);
  printf("Producent dodal %d\n", number);
  printf("%d\n", bufor.size()); //ilosc elementow w buforze
}

void* consumeO (void* consum)
{
 for(int i =0; i<40; ++i)
 {
//   usleep(setSleep());
     odd.p();
	full.p();
   	std::string consumer = "Odd";
	mutex.p();
	consElem(consumer);
	empty.v();
	mutex.v();
  }
}

void* consumeE (void* consum)
{
 for(int i =0; i<40; ++i)
 {
//   usleep(setSleep());
	even.p();
	full.p();
   	std::string consumer = "Even";
	mutex.p();
	consElem(consumer);
	empty.v();
	mutex.v();
  }
}

void* produce (void* produc)
{
  for(int i =0; i<40; ++i)
  {
//	usleep(setSleep());
 //    int producer = (int) produc;
	empty.p();  //sprawdzamy czy producenci moga cos dodac
	mutex.p();  //sprawdzamy czy mozna wejsc do bufora
	prodElem();
	if (bufor.size() > 3) full.v();
	if (bufor.size() == 1) (*bufor.begin() % 2 == 0)?  even.v() : odd.v();
	mutex.v();
  }
}

int main()
{
	srand (time(nullptr));

	pthread_t consFirst;
	pthread_t consSec;
	pthread_t prodFirst;
	pthread_t prodSec;

	int num_prodFirst = 1;
	int num_prodSec = 2;

	pthread_create(&prodFirst, nullptr, produce, (void*) num_prodFirst);
	pthread_create(&prodSec, nullptr, produce, (void*) num_prodSec);
	pthread_create(&consFirst, nullptr, consumeO, nullptr);
	pthread_create(&consSec, nullptr, consumeE, nullptr);

	pthread_join(prodFirst, nullptr);
	pthread_join(prodSec, nullptr);
	pthread_join(consFirst, nullptr);
	pthread_join(consSec, nullptr);

    return 0;
}
