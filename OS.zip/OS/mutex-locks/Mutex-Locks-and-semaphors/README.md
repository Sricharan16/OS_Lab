# Mutex-Locks-and-semaphors
A Simple demonstration of the benefits of locks.
