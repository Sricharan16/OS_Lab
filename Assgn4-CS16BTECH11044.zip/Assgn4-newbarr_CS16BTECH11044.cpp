#include<pthread.h>
#include<time.h>
#include<stdlib.h>
#include<bits/stdc++.h>
#include<semaphore.h>
using namespace std;
double *avg_time;
sem_t mutexi;
sem_t barrier;
int N;
int counti=0;
FILE *fp;
time_t reqtime;
const std::string currentDateTime(time_t peta) {
	time_t     now = peta;
	struct tm  tstruct;
	char       buf[80];
	tstruct = *localtime(&now);
	strftime(buf, sizeof(buf), "%X", &tstruct);
	return buf;
}
const std::string curTime() 
{  //used to calculate the current time
	time_t     now = time(0);
	struct tm  tst;
	char       buf[200];
	tst = *localtime(&now);
	strftime(buf, sizeof(buf), "%X", &tst);
	return buf;
}
string timeconv(time_t tc)
{	//for converting the time to string 
	string te= curTime();
	return te;
}
void testBarrier(time_t pre,time_t post, int k,int p)
{

	time_t beforeBarrSleep,afterBarrSleep;
 // Executing the barrier k times
	sem_wait(&mutexi);
	counti=counti+1;
	sem_post(&mutexi);
	if(counti==N)
		sem_post(&barrier);
	sem_wait(&barrier);
	sem_post(&barrier);
	for(int barrIter=0;barrIter<k;barrIter++){
 // Simulating thread doing some time consuming task before the barrier
		srand(pre);
		beforeBarrSleep=rand();
		
		time(&reqtime);
		thread::id tid;
		tid=this_thread::get_id();
		fprintf(fp, "Going to sleep before the %dth barrier invocation at time: %s by thread  %d\n",barrIter+1,timeconv(reqtime).c_str(),p);
		time_t entrytime,exittime;time(&entrytime);
 //sleep(beforeBarrSleep);
		this_thread::sleep_for(std::chrono::milliseconds(beforeBarrSleep%10));
		
		time(&reqtime);
		tid=this_thread::get_id();
		fprintf(fp, " Before the %dth barrier invocation at time : %s by thread  %d\n",barrIter+1,timeconv(reqtime).c_str(),p);
		
		time(&reqtime);
time(&exittime);//for calculating the time at which the thread exits the barrier
avg_time[p-1]+=(exittime-entrytime)*1000;//calculating the average time 
fprintf(fp, "After the %dth barrier invocation at time: %s by thread %d\n",barrIter+1,timeconv(reqtime).c_str(),p);
 // Simulating thread doing some time consuming task after the barrier
srand(post);
afterBarrSleep = rand();
time(&reqtime);
tid=this_thread::get_id();
fprintf(fp,"Going to sleep after the %dth barrier invocation at time :%s by thread %d\n",barrIter+1,timeconv(reqtime).c_str(),p);
 //sleep(afterBarrSleep);
 this_thread::sleep_for(std::chrono::milliseconds(afterBarrSleep%10));//calculating in milli seconds inorder to get the outputs fast enough 

}
 //measure the time taken to complete k barrier invocations ;


}
int main()
{
 //intialising the barrier part
 //using two semaphores mutexi and barrier

	sem_init(&mutexi,0,1);
	sem_init(&barrier,0,0);//intialisation of the semaphores
	int k,j;
 	time_t pre,post;//seeds which are taken as the input
 	ifstream file0;
	file0.open("inp-params.txt");//reading inputs from the file
	file0>>N>>k>>pre>>post;
	avg_time= new double [N];//array used in storing the average waiting times of the threads
	thread threadsw[N];//declaring the specified number of threads
	fp = fopen("new-barr-log.txt", "w");//writing to the file
	fstream file1;
	file1.open("Average_time.txt",fstream::in|fstream::out|fstream::app);
	for( j=0; j < N;j++ ) 
	{
		threadsw[j]=thread(testBarrier,pre,post,k,j+1);//creating threads
	}
	
	for( int i = 0; i < N; i++ ) 
		threadsw[i].join();  //waiting for the threads execution to finish
	double ss=0;//used in calculated the overall waiting time
	for(int i=0;i<N;i++)
	{
		//Writing the average time taken by thread in running k times to the file Average_time.txt
		file1<<"Average time taken by thread "<<i+1<<" is "<<avg_time[i]/1000<<endl;
		ss=ss+avg_time[i];
	}
	ss=ss/1000;
	file1<<"Average of time taken by all threads is"<<ss/N;
	//Printing the average time taken by all the threads
	return 0;
}
