after de compressing the zip file two codes will be produced 
one has implemented barrier using the pthread barrier and the other was implemented using the semaphores. 

Both the codes can be compiled using the g++ compiler  and linking with the library pthread. 
Use the following lines in the terminal:
g++ Assgn4-newbarr_CS16BTECH11044.cpp -lpthread 
./a.out

Using these commands will produce the files Average_time.txt and a log file new-barr-log.txt and pthread-barr-log.txt which is the log file of the details of the threads. 

Input to both the programs are given through file "inp-params.txt". in the format 
N k pre post
where the symbols follow the usual meaning as given in the question 

Note: two files were written seperately inorder to easify the understandability of the code. They can be merged into a single file making minor changes
