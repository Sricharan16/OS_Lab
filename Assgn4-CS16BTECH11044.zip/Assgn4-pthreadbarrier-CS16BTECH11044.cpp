#include<pthread.h>
#include<time.h>
#include<stdlib.h>
#include<bits/stdc++.h>
using namespace std;
double *avg_time;
pthread_barrier_t mybarrier;//using the predefined barrier
FILE *fp;
time_t reqtime;
const std::string currentDateTime(time_t peta) {
	time_t     now = peta;
	struct tm  tstruct;
	char       buf[80];
	tstruct = *localtime(&now);
	strftime(buf, sizeof(buf), "%X", &tstruct);
	return buf;
}
const std::string curTime() 
{  //used to calculate the current time
	time_t     now = time(0);
	struct tm  tst;
	char       buf[200];
	tst = *localtime(&now);
	strftime(buf, sizeof(buf), "%X", &tst);
	return buf;
}
string timeconv(time_t tc)
{	//for converting the time to string 
	string te= curTime();
	return te;
}
void testBarrier(time_t pre,time_t post, int k,int p)
{

	time_t beforeBarrSleep,afterBarrSleep;
	time_t entrytime,exittime;
 // Executing the barrier k times
 for(int barrIter=0;barrIter<k;barrIter++){
 // Simulating thread doing some time consuming task before the barrier
 	srand(pre);
 beforeBarrSleep=rand();
 
 time(&reqtime);
 thread::id tid;
tid=this_thread::get_id();
 fprintf(fp, "Going to sleep before the %dth barrier invocation at time: %s by thread  %d\n",barrIter+1,timeconv(reqtime).c_str(),p);
 //sleep(beforeBarrSleep);
 time(&entrytime);
 this_thread::sleep_for(std::chrono::milliseconds(beforeBarrSleep%10));
		
 time(&reqtime);
 tid=this_thread::get_id();
 fprintf(fp, " Before the %dth barrier invocation at time : %s by thread  %d\n",barrIter+1,timeconv(reqtime).c_str(),p);
 //barrier_point();
pthread_barrier_wait(&mybarrier);
time(&reqtime);
tid=this_thread::get_id();
 fprintf(fp, "After the %dth barrier invocation at time: %s by thread %d\n",barrIter+1,timeconv(reqtime).c_str(),p);
 // Simulate thread doing some time consuming task after the barrier
 srand(post);

 afterBarrSleep = rand();
 time(&reqtime);
 tid=this_thread::get_id();
 time(&exittime);
 avg_time[p-1]+=(exittime-entrytime)*1000;
 fprintf(fp,"Going to sleep after the %dth barrier invocation at time :%s by thread %d\n",barrIter+1,timeconv(reqtime).c_str(),p);
 //sleep(afterBarrSleep);
 this_thread::sleep_for(std::chrono::milliseconds(afterBarrSleep%10));
}
 //measure the time taken to complete k barrier invocations ;
 
 }
int main()
 {
 //initialising the barrier
 //also creating the threads
 	
 	int N,k,j;
 	time_t pre,post;
	ifstream file0;
	file0.open("inp-params.txt");//reading inputs from the file
	file0>>N>>k>>pre>>post;
	avg_time= new double [N];//array used in storing the average waiting times of the threads
	pthread_barrier_init(&mybarrier,NULL,N);
	thread threadsw[N];//declaring the specified number of threads
	fp = fopen("pthread-barr-log.txt", "w");//writing to the file
	fstream file1;
	file1.open("Average_time.txt",fstream::in|fstream::out|fstream::app);
	for( j=0; j < N;j++ ) 
	{
		threadsw[j]=thread(testBarrier,pre,post,k,j+1);//creating threads
	}
	//pthread_barrier_wait(&mybarrier);
	for( int i = 0; i < N; i++ ) 
		threadsw[i].join();  //waiting for the threads execution to finish
	double ss=0;	
	pthread_barrier_destroy(&mybarrier);
	for(int i=0;i<N;i++)
	{
		//Writing the average time taken by thread in running k times to the file Average_time.txt
		file1<<"Average time taken by thread "<<i+1<<" is "<<avg_time[i]/1000<<endl;
		ss=ss+avg_time[i];
	}
	ss=ss/1000;
	file1<<"Average of time taken by all threads is"<<ss/N;
	//Printing the average time taken by all the threads
	return 0;
 }
