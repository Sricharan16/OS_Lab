#include<bits/stdc++.h>//Readers-Writers problem
#include<semaphore.h>
#include<thread>
using namespace std;
sem_t mtx;//using two semaphores
sem_t rw;
int rc=0;
FILE *fp;//file pointer which is used to print into the file 
int total = 0;
double *avg_time_r;
double *avg_time_w;
int csSeed,remSeed;
const std::string curTime() 
{  //used to calculate the current time
	time_t     now = time(0);
	struct tm  tst;
	char       buf[200];
	tst = *localtime(&now);
	strftime(buf, sizeof(buf), "%X", &tst);
	return buf;
}
string timeconv(time_t tc)
{	//for converting the time to string 
	string te= curTime();
	return te;
}
void reader(int k,int j)//function for the reader thread
{
	thread::id tid;
	tid=this_thread::get_id();//for getting the thread id
	time_t req_time,ent_time,exit_time,randCStime,randremtime;
	int seed;
	for(int i=0;i<k;i++)
	{	
		time(&req_time);	
		fprintf(fp," %d th CS req by %d th reader at %s \n",i,j,timeconv(req_time).c_str());
		/*Start of entry section*/
		sem_wait(&mtx);
		rc++;
		if(rc==1)
			{sem_wait(&rw);}
		sem_post(&mtx);
		/*end of entry section*/
		time(&ent_time);
		total++;
		cout<<total<<endl;
		fprintf(fp," %d th CS ent by %d th reader at %s \n",i,j,timeconv(ent_time).c_str());
		//Start of CS	
		srand(csSeed);
		avg_time_r[j]+=ent_time-req_time;
		randCStime = rand();
		this_thread::sleep_for(std::chrono::milliseconds(randCStime%10));
		//end of CS
		//start of exit section
		sem_wait(&mtx);
		rc--;
		if(rc==0)
			{sem_post(&rw);}
		sem_post(&mtx);
		
		//end of exit section
		time(&exit_time);
		fprintf(fp," %d th CS ext by %d th reader at %s \n",i,j,timeconv(exit_time).c_str());
		//start of remainder section
		srand(remSeed);
		randremtime=rand();
		this_thread::sleep_for(std::chrono::milliseconds(randremtime%10));
		//end of remainder section
	}
}

void writer(int k,int j)//function for the writer thread
{
	thread::id tid;
	tid=this_thread::get_id();//inorder to get the thread id
	time_t req_time,ent_time,exit_time,randCStime,randremtime;
	int seed;
	for(int i=0;i<k;i++)
	{	
		time(&req_time);
		fprintf(fp," %d th CS req by %d th writer at %s \n",i,j,timeconv(req_time).c_str());
		/*Start of entry section*/
		sem_wait(&rw);
		
		/*end of entry section*/
		time(&ent_time);
		total++;
		cout<<total<<endl;
		fprintf(fp," %d th CS ent by %d th writer at %s \n",i,j,timeconv(ent_time).c_str());
		//Start of CS	
		srand(csSeed);
		avg_time_w[j]+=ent_time-req_time;
		randCStime = rand();
		this_thread::sleep_for(std::chrono::milliseconds(randCStime%10));
		//end of CS
		//start of exit section
		sem_post(&rw);
		//end of exit section
		time(&exit_time);
		fprintf(fp," %d th CS ext by %d th writer at %s \n",i,j,timeconv(exit_time).c_str());
		//start of remainder section
		srand(remSeed);
		randremtime=rand();
		this_thread::sleep_for(std::chrono::milliseconds(randremtime%10));
		//end of remainder section
	}
}

int main () 
{
	int nw,nr,kw,kr,k=0,j=0;
	ifstream file0;
	file0.open("inp-params.txt");//reading inputs from the file
	file0>>nw>>nr>>kw>>kr>>csSeed>>remSeed;
	sem_init(&rw,0,1);
	sem_init(&mtx,0,1);
	avg_time_w= new double [nw];
	avg_time_r= new double [nr];
	thread threadsw[nw];
	thread threadsr[nr];//declaring the specified number of threads
	fp = fopen("RW-log.txt", "w");//writing to the file
	fstream file1;
	file1.open("Average_time.txt",fstream::in|fstream::out|fstream::app);
	for( k = 0,j=0; k < nr&&j<nw; k++,j++ ) 
	{
		threadsw[j]=thread(writer,kw,j);//creating threads
		threadsr[k]=thread(reader,kr,k);
	}
	if(k<nr)
		{for(;k<nr;k++)
			threadsr[k]=thread(reader,kr,k);
		}
		else
			{for(;j<nw;j++)	
				threadsw[j]=thread(writer,kw,j);
			}
			for( int i = 0; i < nr; i++ ) 
				threadsr[i].join();
			for( int i = 0; i < nw; i++ ) 
				threadsw[i].join();
	//waiting for the threads execution to finish 
			double sum1=0,sum2=0,avg=0;
			for(int i=0;i<nw;i++)
				sum2+=(avg_time_w[i]);
			sum2/=kw;
			for(int i=0;i<nr;i++)
				sum1+=(avg_time_r[i]);
			sum1/=kr;
			avg=(sum1+sum2)/(nr+nw);
			file1<<"Average waiting timwe for RW algo for "<<kr+kw<<" threads is "<<avg<<endl; 
	//writing the average waiting time to the files
			return 0;
		}
