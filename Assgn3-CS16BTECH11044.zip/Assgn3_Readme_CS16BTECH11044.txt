->Extract the file
->The input to the program will be a file, named inp-params.txt, consisting of the
parameters discussed below:
nw: the number of writer threads, 

nr: the number of reader threads, 

kw: the number of times each writer thread tries to enter the Critical Section, 

kr: the number of times each reader thread tries enter theCS, 

csSeed: the random Critical Section time seed generator which simulates the time spent by each thread executing in Critical Section, 

remSeed: the random remainder section time seed generator which simulates the time spent by each thread executing in remainder section.


->The programs upon execution will produce the following output  files:
1)RW-log.txt and FairRW-log.txt, consisting of events.

2)Average_time.txt- consisting of the average time taken for a thread to gain entry to the
Critical Section for each of the algorithms: RW and Fair-RW.



-> Input file should be named "inp-params.txt" as described above.

->Compile by "g++ Assgn3_RW_CS16BTECH11044.cpp -lrt -lpthread" command .(Linking the pthreads and rt)
 

->Compile by "g++ Assgn3_RW_Fair_CS16BTECH11044.cpp -lrt -lpthread" command .(Linking the pthreads and rt)

->final use ./a.out

->this will finally create the desired output files


