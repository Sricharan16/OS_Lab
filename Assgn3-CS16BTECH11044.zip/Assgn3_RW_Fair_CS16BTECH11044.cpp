#include<bits/stdc++.h>//fair reader-writer solution
#include<thread>
#include<semaphore.h>
using namespace std;
sem_t in;//using three semaphores for fair reader-writer 
sem_t out;
sem_t wrt;
int ctrin=0,ctrout=0,wait=0;
FILE *fp;//file pointer to store the output 
int total = 0;
double *avg_time_r;
double *avg_time_w;
int csSeed,remSeed;
const std::string curTime() 
{    //function for calculating current time
	time_t     now = time(0);
	struct tm  tst;
	char       buf[200];
	tst = *localtime(&now);
	strftime(buf, sizeof(buf), "%X", &tst);
	return buf;
}
string timeconv(time_t tc)
{	//converting the time to string
	string te= curTime();
	return te;
}
void reader(int k,int j)
{
	thread::id tid;
	tid=this_thread::get_id();
	time_t req_time,ent_time,exit_time,randCStime,randremtime;
	int seed;
	for(int i=0;i<k;i++)
	{	
		time(&req_time);
		
		
		fprintf(fp," %d th CS req by %d th reader at %s \n",i,j,timeconv(req_time).c_str());
		/*Start of entry section*/
		sem_wait(&in);
		ctrin++;
		sem_post(&in);
		

		/*end of entry section*/
		time(&ent_time);
		total++;
		cout<<total<<endl;
		fprintf(fp," %d th CS ent by %d th reader at %s \n",i,j,timeconv(ent_time).c_str());
		//Start of CS	
		srand(csSeed);
		avg_time_r[j]+=ent_time-req_time;
		randCStime = rand();
		this_thread::sleep_for(std::chrono::milliseconds(randCStime%10));
		//end of CS
		//start of exit section
		sem_wait(&out);
		ctrout++;
		if(wait==1&&ctrin==ctrout)
			{sem_post(&wrt);}
		sem_post(&out);
		
		//end of exit section
		time(&exit_time);
		fprintf(fp," %d th CS ext by %d th reader at %s \n",i,j,timeconv(exit_time).c_str());
		//start of remainder section
		srand(remSeed);
		randremtime=rand();
		this_thread::sleep_for(std::chrono::milliseconds(randremtime%10));
		//end of remainder section
	}
}

void writer(int k,int j)
{
	thread::id tid;
	tid=this_thread::get_id();
	time_t req_time,ent_time,exit_time,randCStime,randremtime;
	int seed;
	for(int i=0;i<k;i++)
	{	
		time(&req_time);
		fprintf(fp," %d th CS req by %d th writer at %s \n",i,j,timeconv(req_time).c_str());
		/*Start of entry section*/
		sem_wait(&in);
		sem_wait(&out);
		if(ctrin==ctrout)
			sem_post(&out);
		else
		{
			wait=1;
			sem_post(&out);
			sem_wait(&wrt);	
			wait=0;
		}
		
		/*end of entry section*/
		time(&ent_time);
		total++;
		cout<<total<<endl;
		fprintf(fp," %d th CS ent by %d th writer at %s \n",i,j,timeconv(ent_time).c_str());
		//Start of CS	
		srand(csSeed);
		avg_time_w[j]+=ent_time-req_time;
		randCStime = rand();
		this_thread::sleep_for(std::chrono::milliseconds(randCStime%10));
		//end of CS
		//start of exit section
		sem_post(&in);
		//end of exit section
		time(&exit_time);
		fprintf(fp," %d th CS ext by %d th writer at %s \n",i,j,timeconv(exit_time).c_str());
		//start of remainder section
		srand(remSeed);
		randremtime=rand();
		this_thread::sleep_for(std::chrono::milliseconds(randremtime%10));
		//end of remainder section
	}
}

int main () 
{
	int nw,nr,kw,kr,k=0,j=0;
	ifstream file0;
	file0.open("inp-params.txt");//input reading from the file
	
	file0>>nw>>nr>>kw>>kr>>csSeed>>remSeed;
	sem_init(&in,0,1);
	sem_init(&out,0,1);
	sem_init(&wrt,0,0);
	avg_time_r= new double [nr];
	avg_time_w= new double [nw];
	thread threadsr[nr];
	thread threadsw[nw];
	
	
	
	fp = fopen("Fair_RW-log.txt", "w");//Writing to the file
	fstream file1;
	file1.open("Average_time.txt",fstream::in|fstream::out|fstream::app);
	//calculating the average time
	for( k = 0,j=0; k < nr&&j<nw; k++,j++ ) 
	{
		threadsw[j]=thread(writer,kw,j);
		threadsr[k]=thread(reader,kr,k);
		}//creating threads
		if(k<nr)
			{for(;k<nr;k++)
				threadsr[k]=thread(reader,kr,k);
			}
			else
				{for(;j<nw;j++)	
					threadsw[j]=thread(writer,kw,j);
				}
				for( int i = 0; i < nr; i++ ) 
		threadsr[i].join();//waiting for the reader threads to finish execution
	for( int i = 0; i < nw; i++ ) 
		threadsw[i].join();//waiting for the writer threads to finish execution 
	
	double sum1=0,sum2=0,avg=0;
	for(int i=0;i<nr;i++)
		sum1+=(avg_time_r[i])/kr;
	
	for(int i=0;i<nw;i++)
		sum2+=(avg_time_w[i])/kw;
	
	
	avg=(sum1+sum2)/(nr+nw);
	file1<<"Average waiting timwe for Fair RW algo for "<<kr+kw<<" threads is "<<avg<<endl; 
	//Writing the average time to the file
	
	return 0;
}
