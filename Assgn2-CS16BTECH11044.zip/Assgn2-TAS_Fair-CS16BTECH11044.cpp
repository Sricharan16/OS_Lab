#include<iostream>
#include<thread>
#include<bits/stdc++.h>
#include<atomic>
using namespace std; 
std::ostringstream *buffer;
double *average_time;
bool *waiting,key;
time_t csSeed,remSeed;
std::atomic_flag mini = ATOMIC_FLAG_INIT;
const std::string currentDateTime(time_t peta) {
	time_t     now = peta;
	struct tm  tstruct;
	char       buf[80];
	tstruct = *localtime(&now);
    // Visit http://en.cppreference.com/w/cpp/chrono/c/strftime
    // for more information about date/time format
	strftime(buf, sizeof(buf), "%X", &tstruct);
	return buf;
}
void testCS(int k,int loci,int n)
{
	//int id = thread.getID();
	std::thread::id this_id = std::this_thread::get_id();
	//Random csSeed, remSeed;
	time_t reqTime,enterTime,exitTime;
	time_t randCSTime,randRemTime;	int e;
	for(int i=0; i<k ;i++)
	{
		time(&reqTime);
		

		//cout<<i<<"th CS request by Thread "<<this_id<< "at "<<reqTime<<endl;
		buffer[loci]<<i<<"th CS request by Thread "<<loci+1<<" with id "<<this_id<< "at "<<currentDateTime(reqTime)<<endl;
/*
Write your code for

* test_and_set()
* test_and_set() with bounded waiting
* compare_and_swap()
here.
*/       
		waiting[loci]=true;
		key=true;
		while(waiting[loci] && key)
			key=mini.test_and_set(std::memory_order_acquire);
		waiting[loci]=false;
		
		time(&enterTime);
		//cout<<i<<"th CS Entry by Thread "<<this_id<<"at "<<enterTime<<endl;
		buffer[loci]<<i<<"th CS Entry by Thread "<<loci+1<<" with id "<<this_id<<"at "<<currentDateTime(enterTime)<<endl;
		
		srand(csSeed);
		randCSTime = rand();
		
		//sleep(randCSTime); // simulate a thread executing in CS
		std::this_thread::sleep_for(std::chrono::seconds(randCSTime%10));
/*
* Your code for the thread to exit the CS.
*/e=(loci+1)%n;
		while((e!=loci) && !waiting[e])e=(e+1)%n;
		if(e==loci)
			mini.clear(std::memory_order_release); 
		else
			waiting[e]=false;
		average_time[loci]=average_time[loci]+enterTime-reqTime;
		
		time(&exitTime);
//cout<<i<<"th CS Exit by Thread "<<this_id<<"at "<<exitTime<<endl;
		buffer[loci]<<i<<"th CS Exit by Thread "<<loci+1<<" with id "<<this_id<<"at "<<currentDateTime(exitTime)<<endl;
		srand(remSeed);
		randRemTime = rand();
//sleep(randRemTime); // simulate a thread executing in CS
		std::this_thread::sleep_for(std::chrono::seconds(randRemTime%5));
	}
}
int main(int argc, char const *argv[])
{ int n,k,x,y;
	ifstream file;
	file.open ("inp-params.txt");
	file>>n>>k>>x>>y;
	csSeed=x;
	remSeed= y;
	// cin>>n>>k;
	thread mythreads[n];
	buffer=new std::ostringstream[n]; 
	average_time=new double[n];	
	waiting=new bool[n];
	key=false;
	for(int i=0;i<n;i++)
	{
		average_time[i] =0;
		waiting[i]=false;
	}
	for(int i=0;i<n;i++)
	{
		mythreads[i] =thread(testCS,k,i,n);
	}

	// thread t1(task1,"HElLo");
	// t1.join
	for (int i=0; i<n; i++){
		mythreads[i].join();
	}	
	ofstream fileo;
	fileo.open ("TAS_bounded-log.txt");
	ofstream filei;
	filei.open ("TAS_bounded-Average_time.txt");
	for (int i=0; i<n; i++){
		fileo<<buffer[i].str();
	}	
	double sum1=0;
	for(int i=0;i<n;i++)
	{
		filei<<"Average time for thread"<<i+1<<"="<<(double)average_time[i]/k<<endl;
		sum1=sum1+((double)average_time[i]/k);
	}
	filei<<"Total average time for "<<n<<" threads ="<<(double)sum1/n;
	return 0;
}