There are three algorithms written with files Assgn2-TAS-CS16BTECH11044.cpp,Assgn2-TAS_Fair-CS16BTECH11044.cpp and Assgn2-CAS-CS16BTECH11044.cpp

All the algorithms take the input from the file with the name "inp-params.txt"
The first algorithm can be executed using the g++ compiler by linking with the pthread library 
command:
g++ Assgn2-TAS-CS16BTECH11044.cpp -pthread 
./a.out
By using this we will get the desired results in the output text files  "TAS-log.txt" and "TAS-Average_time.txt". The average times for each specific thread and the overall waiting time is calculated.
The second algorithm also can be executed in a similar manner by linking with the pthread library. After compiling the results can be found in "TAS_bounded-log.txt"and "TAS_bounded-Average_time.txt"
The third algorithm also can be executed in a similar manner by linking with the pthread library. After compiling the results can be found in "CAS-log.txt" and  "CAS-Average_time.txt"

The format for the input is:
The number of threads n,
The number of times each thread tries to access the critical section k,
The random CS time seed generator which simulates the time spent by each thread executing in Critical Section,
remSeed:the random remainder section time seed generator
which simulates the time spent by each thread executing in remainder section.
An important note:   As the entire processes are simulated, the output generation is not immediate but will generated within a quite a bit of time. The validity of the code can be checked with lesser n and k for obtaining faster results. 
