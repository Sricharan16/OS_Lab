#include <iostream>
#include <numeric>
#include <math.h>
#include<bits/stdc++.h>
using namespace std;
#define MAX_PROCESS 40

int num_of_process=3, count, remain, time_quantum;
int execution_time[MAX_PROCESS], period[MAX_PROCESS], remain_time[MAX_PROCESS], deadline[MAX_PROCESS], remain_deadline[MAX_PROCESS];
int burst_time[MAX_PROCESS], wait_time[MAX_PROCESS], completion_time[MAX_PROCESS], arrival_time[MAX_PROCESS];
int pid[MAX_PROCESS],repetitions[MAX_PROCESS];
//collecting details of processes
//get maximum of three numbers
int max(int a,int b, int c){
        long max,lcom, count, flag=0;
        if( a>=b && a>=c)
                return max=a;
        else if(b >=a && b>=c)
                return max=b;
        else if(c>=a && c>=b)
                return max=c;
}
//calculating the observation time for scheduling timeline
int get_observation_time(int selected_algo){
 if(selected_algo == 4)
		return max(deadline[0], deadline[1], deadline[2]);
	
}
//print scheduling sequence
void print_schedule(int process_list[], int cycles){
	cout << endl << "Scheduling:-" << endl << endl;
	cout << "Time: ";
	for (int i=0; i<cycles; i++){
		if (i < 10)
			cout << "| 0" << i << " ";
		else
			cout << "| " << i << " ";
	}
	cout << "|" << endl;
	int flags=0;
	// for (int i=0; i<num_of_process; i++){
	// 	cout << "P[" << i+1 << "]: ";
	// 	for (int j=0; j<cycles; j++){
	// 		if (process_list[j] == i+1)
	// 			{
	// 				cout << "|####";
	// 				if(flags!=i+1)
	// 				{
	// 					flags=i+1;
	// 				}
	// 			}
	// 		else
	// 			{
	// 				cout << "|    ";
	// 			}
	// 	}
	// 	cout << "|" << endl;
	// }
	ofstream outfile;
	outfile.open("RM-Log.txt", std::ios_base::app);
	for(int j=0;j<num_of_process;j++)
		cout<<repetitions[j]<<" ";
	for (int j=0; j<cycles; j++)
		{	
			cout<<j+1<<" "<<process_list[j]<<endl;
			if(flags!=process_list[j])
			{	
				if(flags!=0)
					{
					outfile<<"Process P"<<flags<<" finished execution at time"<<j<<endl;
					repetitions[flags-1]--;
					}
				flags=process_list[j];
			if(process_list[j]!=0)
			outfile<<"Process P"<<process_list[j]<<" started execution at time"<<j<<endl;
			}
			
	//else
	
		int counter=0;
		for(int p=0;p<num_of_process;p++)
			{if(repetitions[p]==0)counter++;} 
		cout<<">counter<"<<counter<<endl;
		if(counter==num_of_process)
			break;
		if(repetitions[process_list[j]-1]==0)continue;
	
}	
}
void earliest_deadline_first(int time){
	ofstream outfile;
	outfile.open("RM-Log.txt", std::ios_base::app);
	for (int i = 0; i < num_of_process; i++)
		outfile<<"Process P"<< i+1 <<" :processing time="<<remain_time[i]<<"; deadline:"<<deadline[i]<<"; period:"<<deadline[i]<<" joined the system at time 0"<<endl;
	float utilization = 0;
	for (int i = 0; i < num_of_process; i++){
		utilization += (1.0*execution_time[i])/deadline[i];
	}
	int n = num_of_process;
	if (utilization > 1){
		outfile << endl << "Given problem is not schedulable under said scheduling algorithm." << endl;
		exit(0);
	}

	int process[num_of_process];
	int max_deadline, current_process=0, min_deadline,process_list[time];;
	bool is_ready[num_of_process];

	for(int i=0; i<num_of_process; i++){
		is_ready[i] = true;
		process[i] = i+1; 
	}

	max_deadline=deadline[0];
	for(int i=1; i<num_of_process; i++){
		if(deadline[i] > max_deadline)
			max_deadline = deadline[i];
	}

	for(int i=0; i<num_of_process; i++){
		for(int j=i+1; j<num_of_process; j++){	
			if(deadline[j] < deadline[i]){
				int temp = execution_time[j];
				execution_time[j] = execution_time[i];
				execution_time[i] = temp;
				temp = deadline[j];
				deadline[j] = deadline[i];
				deadline[i] = temp;
				temp = process[j];
				process[j] = process[i];
				process[i] = temp;
			}
		}
	}

	for(int i=0; i<num_of_process; i++){
		remain_time[i] = execution_time[i];
		remain_deadline[i] = deadline[i];
	}

	for (int t = 0; t < time; t++){
		if(current_process != -1){		
			--execution_time[current_process];
			process_list[t] = process[current_process];
		}	
		else
			process_list[t] = 0;
	
		for(int i=0;i<num_of_process;i++){
			--deadline[i];
			if((execution_time[i] == 0) && is_ready[i]){
				deadline[i] += remain_deadline[i];
				is_ready[i] = false;
			}
			if((deadline[i] <= remain_deadline[i]) && (is_ready[i] == false)){
				execution_time[i] = remain_time[i];
				is_ready[i] = true;
			}
		}
	
		min_deadline = max_deadline;		
		current_process = -1;
		for(int i=0;i<num_of_process;i++){
			if((deadline[i] <= min_deadline) && (execution_time[i] > 0)){				
				current_process = i;
				min_deadline = deadline[i];
			}
		}
	}	
	print_schedule(process_list, time);
}

int main(int argc, char* argv[]) {
	int option = 0;
	//cout << "4. Earliest Deadline First" << endl;
	ifstream file;
    file.open ("inp-params.txt");
	//cout << "Select > "; cin >> option;
	//cout << "Enter total number of processes(maximum "<< MAX_PROCESS << "): ";
   	file >> num_of_process;
   	int pid[num_of_process];
	for (int i = 0; i < num_of_process; i++){
		//cout << endl << "Process "<< i+1 << ":-" << endl;
		file>>pid[i];
		//cout << "==> Execution time: ";
		file>> execution_time[i];
		remain_time[i] = execution_time[i];
		//cout << "==> Deadline: ";
		file>> deadline[i];
		file>>repetitions[i];
	}
	//get_process_info(4);		//collecting processes detail
	int observation_time = get_observation_time(4);
	earliest_deadline_first(160);
	return 0;
}
