There are two algorithms written with files Assgn1-RMS-CS16BTECH11044.cpp and Assgn1-EDF-CS16BTECH11044.cpp 

The first algorithm can be executed using the g++ compiler without the help of any linkers
The second algorithm can also be executed using the g++ compiler without any linkers
Both the algorithms take the input from the file with the name "inp-params.txt"
The format for the input is:
The first line contains the number of processes. 
The second n number of lines contain Pi(process id), t(processing time), p(period), k(number of times each process repeats) with spaces between the numbers
It was mentioned in the question that period p and the deadline d for each process is same
Once both the programs are compiled, some results are generated on the console and the output files "RM-Log.txt" and "EDF-Log.txt" are generated which will contain the descrete event schedules and also the average turn around times and the average waiting times along with the missed number of processes statistics. 
Both the algorithms are calculated by hardcoding the time for which the algorithm should be run. In case the outputs are not completely listed in the log files, increase the simulation time in both the main functions of the code.