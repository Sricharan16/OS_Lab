#include<bits/stdc++.h>
#define READY 1
using namespace std;
typedef struct task_node {
    int task_id;
    int period;
    int processingtime;
	int arrival_time;
	int deadline;
	int state;
	int ceu;
	int slacktime;
	int repeattimes;
	int count;
}task;

void read_input(vector<task> &);
void print_task_vec(vector<task> &);
bool comparebyperiod(const task&,const task&);
bool comparebyperiod(const task &a, const task &b) {
	if(a.period < b.period) {
		return true;
	}
	return false;
}
int find_lcm(vector<task> &task_vec , int limit){
    int maax1 , maax2 , counter=1;
    bool notfound=true;
    maax2=maax1=task_vec[limit-1].period;
    while(notfound){
        for(int j=0 ; j<limit-1 ; j++){
            if(!(maax2%task_vec[j].period));
            else break;
            if(j==(limit-2)){
                notfound=false;
                break;
            }
        }
        if(!notfound)
            break;
        else{
           maax2 = maax1*(++counter);
        }
    }
    return maax2;
}
void read_input(vector<task> &task_vector) {
	char input[1024], *tok;
	ifstream file;
    file.open ("inp-params.txt");
	int N,counter,task_id,period,processingtime,index,repeattimes;
	//memset(input,0,1024);
	//fgets(input,1024,stdin) ;
	//N = atoi(input);

	 file>>N;
	index = N;
	char junk;
   
	while ( index>0) {
		
			
				file>>task_id;
				file>>processingtime;
				file>>period;
				file>>repeattimes;
				//file>>junk;
			index--;
		task t;
		t.task_id = task_id;
		t.period = period;
		t.processingtime = processingtime;
		t.arrival_time = 0;
		t.repeattimes=repeattimes;
		t.count=repeattimes;
		t.deadline = t.arrival_time  + t.period;
		t.ceu = 0;
		t.slacktime = (t.deadline - 0) - ( t.processingtime - t.ceu);
		task_vector.push_back(t);
		}
		ofstream myfile;
		myfile.open("RMS-Log.txt");
		for(int i=0;i<N;i++)
		{
			myfile<<"Process P"<<i+1<<": processing time="<<task_vector[i].processingtime<<";period="<<task_vector[i].period<<" joined the system at time 0\n";}


	

}

void print_task_vec(vector<task> &v) {

	int n = v.size();
	int i;

	cout<<"----------------------------------\n";

	cout<<"Task\tPeriod\tprocessingtime\tatime\tdead\tslack\n";

	for (i=0;i<n;i++) { 
		cout<<v[i].task_id<<"\t"<<v[i].period<<"\t"<<v[i].processingtime<<"\t"<<v[i].arrival_time<<"\t"<<v[i].deadline<<"\t"<<v[i].slacktime<<"\t"<<v[i].repeattimes<<endl;
	}
	cout<<"----------------------------------\n";
}




void RMS_Scheduler(vector<task> &task_vec,int sim_time) { 
	ofstream outfile;
	outfile.open("RMS-Log.txt", std::ios_base::app);
	ofstream variablesfinished;
	variablesfinished.open("RM-Stats.txt", std::ios_base::app);
	variablesfinished<<"Number of proccesses that came in system:"<<task_vec.size()<<endl;
	sort(task_vec.begin(),task_vec.end(),comparebyperiod);
	print_task_vec(task_vec);
	int i,time = 0;
	int  n = task_vec.size();
	int A[n][4]={0};//starttime endtime waitingtime turnaroundtime
	int curr_process;
	for(i=0;i<task_vec.size();i++) {
		task_vec[i].arrival_time = time;
		task_vec[i].deadline = task_vec[i].arrival_time + task_vec[i].period;
		task_vec[i].state = READY;
		task_vec[i].ceu = 0;
	}int flags=0;string p= "kill",str;int measure=0;int zest=-1;
int kama=0;	for(int i=0;i<n;i++){A[i][0]=0;A[i][3]=0;}
	while (time < sim_time) {
	set<int> pokemon;

		cout<<"TIME "<<time<<endl;
		curr_process = -1;
		for(i=0;i<n;i++) {
			if(task_vec[i].state==READY && task_vec[i].arrival_time <= time && task_vec[i].repeattimes!=0) {
				if(p!="kill" && measure>1)
				{
					outfile<<p<<endl;
					
					p="kill";
				}
				measure=0;
				cout<<"\tEXECUTING TASK "<<i+1<<endl;
				pokemon.insert(i+1);
				if(flags!=i+1)
				{string strcomp="Process P"+to_string(i+1)+" started its execution at time "+to_string(time);
				outfile<<strcomp<<endl;
				 flags=i+1;
				}
				curr_process = i;
				// if(A[i][0]==-1)
				// 	A[i][0]=time;
				// else
				// A[i][0]=min(A[i][0],time);
				break;
			}
		
		}if(kama==0){A[curr_process][0]=0;kama=1;}
		if(curr_process > -1 && task_vec[curr_process].repeattimes!=0) {
			task_vec[curr_process].ceu++;
			if (task_vec[curr_process].ceu == task_vec[curr_process].processingtime) {
				cout<<"\tTASK COMPLETED "<<curr_process+1<<endl;
				A[curr_process][1]=time+1;
				A[curr_process][3]=A[curr_process][3]+A[curr_process][1]-A[curr_process][0];
				A[curr_process][0]=A[curr_process][0]+task_vec[curr_process].period;
				//A[curr_process][2]=A[curr_process][3]-task_vec[curr_process].processingtime;
				//A[curr_process][0]=A[curr_process][0]+task_vec[curr_process].period;
				pokemon.erase(curr_process+1);
				outfile<<"Process P"<<curr_process+1<<" finishes its execution at time "<<time+1<<endl;
				task_vec[curr_process].repeattimes--;
				task_vec[curr_process].arrival_time += task_vec[curr_process].period;
				task_vec[curr_process].deadline = task_vec[curr_process].arrival_time + task_vec[curr_process].period;
				task_vec[curr_process].state = READY;
				sort(task_vec.begin(),task_vec.end(),comparebyperiod);
				task_vec[curr_process].ceu = 0;
	
			}
			else if(task_vec[curr_process].ceu < task_vec[curr_process].processingtime && zest!=curr_process)
				{zest=curr_process;cout<<curr_process<<" "<<">preempted<\n";}
			
		}
		for(i=0;i<task_vec.size();i++) {
			if(task_vec[i].deadline < time && task_vec[i].repeattimes!=0 && task_vec[i].state!=0) {
				cout<<"\tTASK "<<i+1<<" missed deadline"<<endl;
				outfile<<"Process P"<<i+1<<" missed its deadline at time "<<time-1<<endl;
				pokemon.erase(i+1);
				task_vec[i].repeattimes--;
				task_vec[i].arrival_time += task_vec[i].period;
				task_vec[i].deadline = task_vec[i].arrival_time + task_vec[i].period;
				task_vec[i].state = 0;
				sort(task_vec.begin(),task_vec.end(),comparebyperiod);
				task_vec[i].ceu = 0;

			}
		}
		
		for (int i = 0; i < task_vec.size(); ++i)
		{
			if(task_vec[i].repeattimes==0)
				{cout<<"TASK "<<i+1<<"finished its specfied number of times"<<endl;}
		}
		//print_task_vec(task_vec);
		if(pokemon.size()==0)
		{
		measure++;
		 p="The CPU is idle till "+to_string(time);
		 cout<<p;
		}time++;

	for(int i=0;i<n;i++)
	{
		for(int j=0;j<4;j++)
			cout<<A[i][j]<<" ";
		cout<<endl;
	}
	}
		print_task_vec(task_vec);
int exhausted=0;
	for (int i = 0; i < task_vec.size(); ++i)
		{
			if(task_vec[i].state==0)
				{exhausted++;}
		}
		variablesfinished<<"Number of processes that missed are:"<<exhausted<<endl;
		variablesfinished<<"Number of processes that finished are:"<<task_vec.size()-exhausted<<endl;
		

		int w[n];float avgwaitingtime=0,avgturnaroundtime=0;
		for(int i=0;i<n;i++)
		{
			w[i]=A[i][3]-(task_vec[i].processingtime*task_vec[i].count);
			avgwaitingtime=avgwaitingtime+w[i];
			avgturnaroundtime=avgturnaroundtime+((float)A[i][3]/task_vec[i].count);
		}
		for(int i=0;i<n;i++)
		{
			variablesfinished<<"Average waiting process for Process P"<<i+1<<": "<<w[i]/task_vec[i].count<<endl;
			//w[i]=A[i][3]-(task_vec[i].processingtime*task_vec[i].count);
			//avgwaitingtime=avgwaitingtime+w[i];
			//avgturnaroundtime=avgturnaroundtime+((float)A[i][3]/task_vec[i].count);
		}
		avgturnaroundtime=(float)avgturnaroundtime/n;
		avgwaitingtime=(float)avgwaitingtime/n;
		cout<<"The average waiting time:"<<avgwaitingtime<<endl;
		cout<<"The average turn around time:"<<avgturnaroundtime<<endl;
		outfile<<endl<<"The average waiting time:"<<abs(avgwaitingtime)<<endl;
		outfile<<"The average turn around time:"<<abs(avgturnaroundtime)<<endl;

}
int main() {
	vector<task> task_vec;
	int n=185;
	read_input(task_vec);
	int lcm=find_lcm(task_vec ,task_vec.size());
	double utilization=0;
    int totalExecutionTime=0;
    for(int i=0 ; i<task_vec.size() ; i++){
        totalExecutionTime+=(lcm/task_vec[i].period)*task_vec[i].processingtime;
    }

    if(totalExecutionTime > lcm){
        cout <<"\nTotal execution time is more than LCM so RMS is not feasible here" << endl;
        return 0;
    }

    utilization=(totalExecutionTime*1.0/lcm) *100;
    cout << setprecision(4)<<"\nUtilization = " << utilization << "%\n";
	print_task_vec(task_vec);
	RMS_Scheduler(task_vec,n);

}

